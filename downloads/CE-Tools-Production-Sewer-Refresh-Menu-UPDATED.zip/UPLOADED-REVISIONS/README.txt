The re-uploaded DrawingSheetImportCommands file is byte-for-byte identical to the previous upload (SHA-256 9520286258adcace4795f8cefee738fe421aaae9327791eab647ce7bd5ee7d54).
The active COMMAND-UPDATES/DrawingSheetImportCommands.cs already incorporates this code plus the layer-copy safeguards and themed messages added on 24 November 2026. Those improvements are retained.
This folder preserves the exact upload for reference. Do not compile both copies: they declare the same commands/classes. The supplied update installer installs only COMMAND-UPDATES.
