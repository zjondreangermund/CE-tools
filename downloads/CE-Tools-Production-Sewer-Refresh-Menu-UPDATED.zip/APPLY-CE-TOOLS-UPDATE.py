#!/usr/bin/env python3
"""Targeted, idempotent CE Tools patch for a COMPLETE source checkout.

Preserves every unrelated source file, ribbon/menu command and DLL reference.
Supports --check and --dry-run. Does not compile or install Civil 3D.
"""
from __future__ import annotations
import argparse
import re
import shutil
import subprocess
import sys
from pathlib import Path

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('repository', type=Path, help='Path to extracted FULL CE-tools-main repository')
parser.add_argument('--dry-run', action='store_true', help='Report proposed changes without writing')
parser.add_argument('--check', action='store_true', help='Verify update only; do not write')
parser.add_argument('--skip-tests', action='store_true', help='Skip the repo source validators')
args = parser.parse_args()
root = args.repository.expanduser().resolve()
source = root / 'src' / 'CE.Tools.Civil3D'
required = [
    'August13SewerMultiSourceNetworkCommands.cs',
    'September09SewerSurfaceRulesRuntime.cs',
    'RefreshAllCommands.cs',
    'DynamicRefreshContextMenu.cs',
    'PluginEntry.cs',
]
missing = [name for name in required if not (source / name).is_file()]
if missing:
    sys.exit('ERROR: This is not a complete CE Tools source checkout; missing: ' + ', '.join(missing) +
             '\nDo not run this patch on the 11-file ribbon-only reference bundle.')

new_contents: dict[Path, str] = {}
changed: list[Path] = []

def get(path: Path) -> str:
    if path not in new_contents:
        new_contents[path] = path.read_text(encoding='utf-8-sig') if path.exists() else ''
    return new_contents[path]

def update(path: Path, value: str) -> None:
    if get(path) != value:
        new_contents[path] = value
        if path not in changed:
            changed.append(path)

def replace_once(text: str, before: str, after: str, label: str) -> str:
    if after in text:
        return text
    if before not in text:
        raise ValueError('Expected source anchor not found: ' + label)
    return text.replace(before, after, 1)

try:
    # Restore the actual surface-first Civil 3D runtime, rather than a second
    # duplicate command implementation that omits surface/rule-set/spacing fields.
    path = source / 'August13SewerMultiSourceNetworkCommands.cs'
    text = get(path)
    if 'September09SewerSurfaceRulesRuntime.CreateNetworkFromMultipleSources(' not in text:
        marker = 'public void CreateSewerNetworkFromMultipleSources()'
        start = text.find(marker)
        if start < 0: raise ValueError('CE_SEWERNETWORKMULTI entry method missing')
        left = text.find('{', start)
        if left < 0: raise ValueError('SEWERNETWORKMULTI opening brace missing')
        depth, right = 0, -1
        # The method in this file contains no interpolated C# braces in strings;
        # verify the method boundary before editing it.
        for i in range(left, len(text)):
            if text[i] == '{': depth += 1
            elif text[i] == '}':
                depth -= 1
                if depth == 0:
                    right = i + 1
                    break
        if right < 0: raise ValueError('SEWERNETWORKMULTI closing brace missing')
        new_method = '''public void CreateSewerNetworkFromMultipleSources()
        {
            // Reuse the established surface-first implementation, preserving
            // its reference surface, pipe/structure rule sets, connected nodes,
            // configurable spacing, parts lists and source-object options.
            Document document = AcApplication.DocumentManager.MdiActiveDocument;
            CivilDocument civilDocument = CivilApplication.ActiveDocument;
            if (document == null || civilDocument == null) return;
            September09SewerSurfaceRulesRuntime.CreateNetworkFromMultipleSources(
                document, civilDocument);
        }'''
        update(path, text[:start] + new_method + text[right:])

    path = source / 'September09SewerSurfaceRulesRuntime.cs'
    text = get(path)
    text = replace_once(text,
        'setup.AddPositiveDouble("MaxSpacing", "03 Creation", "Maximum structure spacing", 60.0,',
        'setup.AddPositiveDouble("MaxSpacing", "03 Creation", "Maximum structure spacing", 80.0,',
        'structure-spacing default')
    text = replace_once(text, 'setup.Double("MaxSpacing", 60.0)',
        'setup.Double("MaxSpacing", 80.0)', 'structure-spacing fallback')
    update(path, text)

    path = source / 'RefreshAllCommands.cs'
    text = get(path)
    # Silent by default, even for drawings with old opt-ins. The user can opt
    # back in manually with CE_AUTOREFRESH in the CE Tools right-click menu.
    text = replace_once(text,
        'if (dictionary == null || !dictionary.Contains(RecordName)) return true;',
        'if (dictionary == null || !dictionary.Contains(RecordName)) return false;',
        'notification default')
    text = replace_once(text,
        'if (record == null || record.Data == null) return true;',
        'if (record == null || record.Data == null) return false;',
        'missing notification record')
    text = text.replace('"NoticeOnV2"', '"NoticeOnV3"')
    text = replace_once(text,
        'if (string.Equals(text, "On", StringComparison.OrdinalIgnoreCase)) return true;',
        'if (string.Equals(text, "NoticeOnV3", StringComparison.OrdinalIgnoreCase)) return true;',
        'legacy notification values')
    text = replace_once(text,
        'new TypedValue((int)DxfCode.Text, enabled ? "On" : "Off")',
        'new TypedValue((int)DxfCode.Text, enabled ? "NoticeOnV3" : "Off")',
        'opt-in notification setting')
    fallback_anchor = '            return true;\n        }\n\n        public static void SetEnabled(Database database, bool enabled)'
    if fallback_anchor in text:
        text = text.replace(fallback_anchor,
            '            return false; // Notifications opt-in only; manual refresh remains available.\n'
            '        }\n\n        public static void SetEnabled(Database database, bool enabled)', 1)
    elif not re.search(r'return false;[^\n]*\n        }\n\n        public static void SetEnabled', text):
        raise ValueError('notification fallback was not found')
    if '"CE_REFRESHDISMISS"' not in text:
        anchor = '        [CommandMethod(\n            "CE_TOOLS",\n            "CE_REFRESHSTATUS",'
        if anchor not in text: raise ValueError('refresh status anchor missing')
        handler = '''        [CommandMethod("CE_TOOLS", "CE_REFRESHDISMISS", CommandFlags.Modal)]
        public void DismissLinkedOutputNotice()
        {
            Document document = ActiveDocument();
            if (document == null) return;
            // The previous popup's Ignore button did exactly this. No drawing
            // entities are edited, and no linked quantities are rebuilt.
            LinkedTableAutoRefreshManager.ClearPending(document);
            document.Editor.WriteMessage(
                "\\nCE Tools: linked-output reminder dismissed. No drawing data was changed or refreshed.");
        }

'''
        text = text.replace(anchor, handler + anchor, 1)
    update(path, text)

    path = source / 'DynamicRefreshContextMenu.cs'
    text = get(path)
    anchor = '                var refreshItem = new MenuItem("CE Dynamic Refresh All");'
    if anchor not in text: raise ValueError('CE Tools right-click menu anchor missing')
    context_actions = [
        ('Refresh Linked CE Outputs', 'CE_REFRESHALL'),
        ('Ignore / Dismiss Linked Reminder', 'CE_REFRESHDISMISS'),
        ('Linked Output Refresh Status', 'CE_REFRESHSTATUS'),
        ('Out-of-Date Notice On / Off', 'CE_AUTOREFRESH'),
    ]
    missing_actions = [
        f'                AddCommandItem(extension, "{label}", "{command}");\n'
        for label, command in context_actions
        if f'AddCommandItem(extension, "{label}", "{command}");' not in text
    ]
    if missing_actions:
        text = text.replace(anchor, ''.join(missing_actions) + '\n' + anchor, 1)
    update(path, text)

    path = source / 'PluginEntry.cs'
    text = get(path)
    text = ''.join(line for line in text.splitlines(keepends=True)
                   if 'Cmd("Out-of-Date Notifications", "CE_AUTOREFRESH "' not in line)
    update(path, text)

    path = root / 'scripts' / 'Validate-RefreshAll.py'
    if path.exists():
        text = get(path)
        text = replace_once(text,
            'WINDOW = SOURCE_DIR / "FloatingToolsWindow.cs"',
            'WINDOW = SOURCE_DIR / "FloatingToolsWindow.cs"\nCONTEXT_MENU = SOURCE_DIR / "DynamicRefreshContextMenu.cs"',
            'validator context-menu path')
        text = replace_once(text,
            '    "workflow window": WINDOW,',
            '    "workflow window": WINDOW,\n    "context menu": CONTEXT_MENU,',
            'validator context-menu mapping')
        text = replace_once(text,
            'window = texts["workflow window"]',
            'window = texts["workflow window"]\nmenu = texts["context menu"]',
            'validator context-menu content')
        legacy = '''    if f'"{command} "' not in plugin:
        errors.append(f"Shared refresh ribbon entry is missing: {command}")'''
        updated = '''    if command == "CE_AUTOREFRESH":
        if f'"{command}"' not in menu:
            errors.append("Notice toggle missing from CE Tools right-click menu")
        if f'"{command} "' in plugin:
            errors.append("Notice setting still visible on main ribbon")
    elif f'"{command} "' not in plugin:
        errors.append(f"Shared refresh ribbon entry is missing: {command}")'''
        if legacy in text:
            text = text.replace(legacy, updated, 1)
        elif 'if command == "CE_AUTOREFRESH":' not in text:
            raise ValueError('validator ribbon expectation not recognized')
        text = text.replace('"NoticeOnV2"', '"NoticeOnV3"')
        text = text.replace("'if (string.Equals(text, \"NoticeOnV2\", StringComparison.OrdinalIgnoreCase)) return true'",
            "'if (string.Equals(text, \"NoticeOnV3\", StringComparison.OrdinalIgnoreCase)) return true'")
        # A previously patched validator may already check menu actions.
        if '"Ignore / Dismiss Linked Reminder", "CE_REFRESHDISMISS"' not in text:
            marker = 'refresh_markers = ('
            check = '''for marker in (
    '"Refresh Linked CE Outputs", "CE_REFRESHALL"',
    '"Ignore / Dismiss Linked Reminder", "CE_REFRESHDISMISS"',
    '"Linked Output Refresh Status", "CE_REFRESHSTATUS"',
):
    if marker not in menu:
        errors.append("Missing CE Tools manual refresh menu action: " + marker)

'''
            if marker not in text: raise ValueError('validator refresh marker missing')
            text = text.replace(marker, check + marker, 1)
        update(path, text)

    # Install the supplied complete command owners under canonical filenames.
    # The sewer upload is a replacement for the existing multi-command class,
    # not an additional CE_SEWERLAYOUTROADRESERVE owner.
    payload = Path(__file__).resolve().parent / 'COMMAND-UPDATES'
    command_files = ('CeErfGroupBoundaryCommands.cs', 'August20GeometryFirstSewerCommands.cs',
                     'OrthogonalPolylineNetworkCommands.cs', 'September05FieldGeometryCommandFrontDoor.cs',
                     'SewerStructureIntervalPlanner.cs', 'SewerStructureIntervalUpdateCommands.cs', 'FinalSewerProductionCommands.cs', 'SewerNetworkDynamicSequenceManager.cs', 'UniversalDynamicRefreshCommands.cs',
                     'SurfaceCropAndReduceCommands.cs', 'AutoCADObjectHoverCommand.cs', 'RoadModelHoverCommand.cs', 'NetworkModelHoverCommand.cs', 'HoverInspectorForm.cs', 'DynamicRefreshContextMenu.cs')
    for filename in command_files:
        supplied = payload / filename
        if not supplied.is_file():
            raise ValueError('Missing command payload: ' + filename)
        update(source / filename, supplied.read_text(encoding='utf-8-sig'))

    # Abort before writing if a differently named file already owns these classes
    # or commands. Never remove unrelated code automatically.
    command_pattern = re.compile(r'\[CommandMethod\(\s*"CE_TOOLS"\s*,\s*"([^"]+)"')
    class_pattern = re.compile(r'^(?: {4})?(?:public|internal)\s+(?:(?:sealed|static)\s+)?class\s+(\w+)', re.MULTILINE)
    incoming_commands = set()
    incoming_classes = set()
    for filename in command_files:
        incoming_commands.update(command_pattern.findall(new_contents[source / filename]))
        incoming_classes.update(class_pattern.findall(new_contents[source / filename]))
    for existing in source.rglob('*.cs'):
        if existing in [source / name for name in command_files]:
            continue
        text = new_contents.get(existing, existing.read_text(encoding='utf-8-sig'))
        duplicates = incoming_commands.intersection(command_pattern.findall(text))
        # Existing September 05 staging deliberately transfers these two aliases
        # from the September 04 helper to the front door. The repository registry
        # validator checks that the corresponding staged handoff remains present.
        if existing.name == 'September04FieldGeometryCompletionCommands.cs':
            duplicates -= {'CE_MULTIFILLET', 'CE_GRIDDIFFERENCE'}
        duplicate_classes = incoming_classes.intersection(class_pattern.findall(text))
        if duplicates or duplicate_classes:
            raise ValueError('Duplicate supplied owner in ' + existing.name + ': ' +
                             ', '.join(sorted(duplicates | duplicate_classes)))

    # String-level safety check before modifying any files.
    final = {p.name: new_contents[p] for p in new_contents if p.suffix == '.cs'}
    assert 'September09SewerSurfaceRulesRuntime.CreateNetworkFromMultipleSources(' in final['August13SewerMultiSourceNetworkCommands.cs']
    assert 'setup.Double("MaxSpacing", 80.0)' in final['September09SewerSurfaceRulesRuntime.cs']
    assert '"CE_REFRESHDISMISS"' in final['RefreshAllCommands.cs']
    assert 'NoticeOnV3' in final['RefreshAllCommands.cs']
    for title in ('Refresh Linked CE Outputs', 'Ignore / Dismiss Linked Reminder',
                  'Linked Output Refresh Status'):
        assert title in final['DynamicRefreshContextMenu.cs']
    assert 'Cmd("Out-of-Date Notifications", "CE_AUTOREFRESH "' not in final['PluginEntry.cs']

except Exception as error:
    sys.exit('ERROR: No files were modified. ' + str(error))

if args.check and changed:
    print('Update incomplete. Files requiring patch:')
    for path in changed: print('  ' + str(path.relative_to(root)))
    sys.exit(2)
if args.dry_run:
    print('DRY RUN: The following files would be updated:')
    for path in changed: print('  ' + str(path.relative_to(root)))
    sys.exit(0)

for path in changed:
    old_path = path.with_suffix(path.suffix + '.before-ce-update.bak')
    if path.exists() and not old_path.exists(): shutil.copy2(path, old_path)
    tmp = path.with_suffix(path.suffix + '.ce-update.tmp')
    tmp.write_text(new_contents[path], encoding='utf-8')
    tmp.replace(path)
print(f'CE Tools integration: {len(changed)} file(s) updated; all others preserved.')
for path in changed: print('  ' + str(path.relative_to(root)))

if not args.skip_tests:
    for name in ('Validate-RefreshAll.py', 'Validate-CommandRegistry.py'):
        validator = root / 'scripts' / name
        if validator.exists():
            print('Running', name)
            try:
                result = subprocess.run([sys.executable, str(validator)], cwd=root, check=False)
                if result.returncode:
                    sys.exit(f'FAILED: {name}. Inspect the output before installing.')
            except OSError as error:
                sys.exit(f'Cannot run {name}: {error}')
print('Ready for Windows Civil 3D 2023/2024 safe BUILD. A native compile and runtime test are still required.')
