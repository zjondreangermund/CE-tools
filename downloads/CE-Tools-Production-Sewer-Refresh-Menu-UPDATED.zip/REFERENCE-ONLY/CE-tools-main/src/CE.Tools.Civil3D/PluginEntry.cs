using System;
using System.Linq;
using System.Windows.Input;
using Autodesk.AutoCAD.Runtime;
using Autodesk.Windows;
using AcApplication = Autodesk.AutoCAD.ApplicationServices.Core.Application;

[assembly: ExtensionApplication(typeof(CETools.Civil3D.PluginEntry))]
[assembly: CommandClass(typeof(CETools.Civil3D.BellmouthDensifierCommand))]

namespace CETools.Civil3D
{
    public sealed class PluginEntry : IExtensionApplication
    {
        private static bool _ribbonCreated;

        public void Initialize()
        {
            ParkingOptionAutoRefreshManager.Initialize();
            DynamicSectionUpdateManager.Initialize();
            // Keep the historic PluginEntry manager anchor intact for the
            // version-specific installer repair script; initialize CE WPF
            // styling immediately after that existing compatibility block.
            CeInterfaceTheme.Initialize();
            DynamicIntersectionUpdateManager.Initialize();
            AnnotationScaleSyncManager.Initialize();
#if CE_CIVIL3D_2024
            PaperSpaceTextAnnotationGuard.Initialize();
            ViewportTextUprightManager.Initialize();
#endif
            DynamicRefreshContextMenu.Attach();
            ParkingNumberAutoRefreshManager.Initialize();
            WaterSewerCostAutoRefreshManager.Initialize();
            LinkedTableAutoRefreshManager.Initialize();
            CommandUsageTracker.Initialize();
            FloatingToolsCommands.Initialize();
            ProjectStylePresetManager.Initialize();
            CogoPointProjectStyleManager.Initialize();
            SewerNetworkDynamicSequenceManager.Initialize();
            CeInteractionTelemetryManager.Initialize();
            UniversalDynamicRefreshManager.Initialize();
            PlatformDynamicRefreshManager.EnsureInitialized();
            August24RoadElevationDynamicManager.Initialize();
            October03PlotPdfManager.Initialize();
            CeGlobalShortcutManager.Initialize();
            August11SurveyRuntimeManager.Initialize();
            RoadAlignmentNameSync.Initialize();
            AcApplication.Idle += OnApplicationIdle;
        }

        public void Terminate()
        {
            AcApplication.Idle -= OnApplicationIdle;
            DynamicRefreshContextMenu.Detach();
            UniversalDynamicRefreshManager.Terminate();
            August24RoadElevationDynamicManager.Terminate();
            October03PlotPdfManager.Terminate();
            RoadAlignmentNameSync.Terminate();
            CeInteractionTelemetryManager.Terminate();
            SewerNetworkDynamicSequenceManager.Terminate();
            CogoPointProjectStyleManager.Terminate();
            ProjectStylePresetManager.Terminate();
            August11SurveyRuntimeManager.Terminate();
            CeGlobalShortcutManager.Terminate();
            FloatingToolsCommands.Terminate();
            CommandUsageTracker.Terminate();
            LinkedTableAutoRefreshManager.Terminate();
            WaterSewerCostAutoRefreshManager.Terminate();
            ParkingNumberAutoRefreshManager.Terminate();
#if CE_CIVIL3D_2024
            ViewportTextUprightManager.Terminate();
            PaperSpaceTextAnnotationGuard.Terminate();
#endif
            AnnotationScaleSyncManager.Terminate();
            DynamicIntersectionUpdateManager.Terminate();
            DynamicSectionUpdateManager.Terminate();
            ParkingOptionAutoRefreshManager.Terminate();
        }

        private static void OnApplicationIdle(object sender, EventArgs e)
        {
#if CE_CIVIL3D_2024
            // The 2024 startup ribbon can be replaced when the first DWG opens
            // or the active workspace changes. Recheck only the tab identities
            // on Idle and recreate them if AutoCAD has discarded them.
            // Do not alter the legacy 2023 one-time startup path.
            try
            {
                RibbonControl currentRibbon = ComponentManager.Ribbon;
                if (currentRibbon == null) return;
                bool hasMainTab = currentRibbon.Tabs.Any(tab => tab.Id == "CE_TOOLS_RIBBON_TAB");
                bool hasProductionTab = currentRibbon.Tabs.Any(tab =>
                    tab.Id == "CE_PRODUCTION_PROJECT_TAB");
                // Check both stable tab IDs, not captions, so a workspace reset
                // can restore either missing ribbon without rebuilding continuously.
                if (_ribbonCreated && hasMainTab && hasProductionTab) return;
                RibbonBuilder.EnsureCreated();
                ProductionWorkflowRibbonBuilder.EnsureCreated();
                _ribbonCreated = true;
            }
            catch
            {
                // Opening/closing drawings can temporarily detach the 2024 ribbon.
                // Retry on the next application Idle without throwing into AutoCAD.
            }
#else
            if (_ribbonCreated)
            {
                AcApplication.Idle -= OnApplicationIdle;
                return;
            }

            try
            {
                _ribbonCreated = RibbonBuilder.EnsureCreated() && ProductionWorkflowRibbonBuilder.EnsureCreated();
                if (_ribbonCreated)
                {
                    // The workflow command centre must appear once when the
                    // first Civil 3D session has a usable CE Tools ribbon.
                    // Opening it before this point produces an empty window.
                    Autodesk.AutoCAD.ApplicationServices.Document activeDocument = AcApplication.DocumentManager.MdiActiveDocument;
                    if (activeDocument != null)
                        activeDocument.SendStringToExecute("CE_WELCOME ", true, false, true);
                    AcApplication.Idle -= OnApplicationIdle;
                }
            }
            catch
            {
                // Civil 3D can raise Idle before its ribbon is fully initialized.
            }
#endif
        }
    }

    /// <summary>
    /// Builds a compact, presentation-ready CE Tools ribbon. Each engineering area
    /// receives a clearly named panel with large branded flyout buttons. Detailed
    /// commands stay inside the flyouts so the tab remains usable on smaller screens.
    /// </summary>
    internal static class RibbonBuilder
    {
        private const string TabId = "CE_TOOLS_RIBBON_TAB";
        private const string ProjectPanelId = "CE_TOOLS_CATEGORY_PROJECT";
        private const string SurveyPanelId = "CE_TOOLS_CATEGORY_SURVEY";
        private const string DrawingsPanelId = "CE_TOOLS_CATEGORY_DRAWINGS";
        private const string GeometryPanelId = "CE_TOOLS_CATEGORY_GEOMETRY";
        private const string AssemblyPanelId = "CE_TOOLS_CATEGORY_ASSEMBLY";
        private const string RoadProductionPanelId = "CE_TOOLS_CATEGORY_ROAD_PRODUCTION";
        private const string CorridorPanelId = "CE_TOOLS_CATEGORY_CORRIDORS";
        private const string SiteDesignPanelId = "CE_TOOLS_CATEGORY_SITE_DESIGN";
        private const string UtilitiesPanelId = "CE_TOOLS_CATEGORY_UTILITIES";
        private const string StandardsPanelId = "CE_TOOLS_CATEGORY_STANDARDS";
        private const string AnalysisPanelId = "CE_TOOLS_CATEGORY_ANALYSIS";
        private const string AdvancedPanelId = "CE_TOOLS_CATEGORY_ADVANCED";
        private const string ProductionPanelId = "CE_TOOLS_CATEGORY_PRODUCTION";

        public static bool EnsureCreated()
        {
            RibbonControl ribbon = ComponentManager.Ribbon;
            if (ribbon == null) return false;

            RibbonTab tab = ribbon.Tabs.FirstOrDefault(item => item.Id == TabId);
            if (tab == null)
            {
                tab = new RibbonTab { Id = TabId, Title = "CE TOOLS" };
                ribbon.Tabs.Add(tab);
            }
            else
            {
                tab.Title = "CE TOOLS";
            }

            // CE Tools owns this tab. Rebuild it so stale panels and duplicate
            // buttons cannot remain after an upgrade or ribbon reload.
            tab.Panels.Clear();
            try
            {
                BuildPanels(tab);
            }
            catch (System.Exception firstException)
            {
                // Runtime icon rendering varies between Civil 3D display stacks.
                // A text-only retry guarantees that the tab never remains blank.
                RibbonVisuals.SetMode(RibbonIconMode.TextOnly);
                tab.Panels.Clear();
                try
                {
                    BuildPanels(tab);
                }
                catch
                {
                    tab.Panels.Clear();
                    throw new InvalidOperationException(
                        "CE Tools could not build its ribbon panels. " +
                        firstException.Message,
                        firstException);
                }
            }
            return true;
        }

        private static void BuildPanels(RibbonTab tab)
        {
            // Keep the main CE Tools ribbon intentionally compact. Production tabs
            // expose only their FINAL workflow entry point; all individual/specialist
            // commands are accessed through the CE Engineering Centre palette.
            AddPanel(tab, "CE_TOOLS_HOME_PANEL", "CE-HOME",
                Row(Menu("CE_TOOLS_HOME_MENU", "CE-Tools Home",
                    "Open the CE Tools welcome and navigation window.",
                    Cmd("CE-Tools Home", "CE_WELCOME ", "Open CE Tools Home."))));

            AddPanel(tab, "CE_TOOLS_ENGINEERING_PANEL", "CE-ENGINEERING CENTRE",
                Row(Menu("CE_TOOLS_ENGINEERING_MENU", "CE-Engineering Centre",
                    "Browse all CE Tools commands and specialist workflows.",
                    Cmd("CE-Engineering Centre", "CE_ENGINEERINGINTELLIGENCECENTRE ", "Open the full CE Tools command library."))));

            AddPanel(tab, "CE_TOOLS_HELP_PANEL", "CE-HELP",
                Row(Menu("CE_TOOLS_HELP_MENU", "CE-Tools Help",
                    "Search CE Tools command help and instructions.",
                    Cmd("CE-Tools Help Centre", "CE_HELP ", "Open the CE Tools Help Centre."))));

            AddPanel(tab, "CE_TOOLS_SETTINGS_PANEL", "CE-SETTINGS",
                Row(Menu("CE_TOOLS_SETTINGS_MENU", "CE-Tools Settings",
                    "Configure CE Tools appearance and user preferences.",
                    Cmd("CE-Tools Appearance", "CE_CETHEME ", "Choose the CE Tools dark or light appearance."))));
        }

        private static void AddAssemblyPanel(RibbonTab tab)
        {
            AddPanel(
                tab,
                AssemblyPanelId,
                "CE-ASSEMBLY",
                Row(
                    Menu(
                        "CE_TOOLS_ASSEMBLY_MENU",
                        "CE Road\nAssemblies",
                        "Create and review Civil 3D road assemblies before corridor generation.",
                        Cmd("Assembly Workflow", "CE_ASSEMBLYTOOLS ", "Open the ordered CE assembly workflow."),
                        Cmd("Create CE Road Assembly", "CE_ASSEMBLYCREATE ", "Create a named Civil 3D road assembly at a selected insertion point."),
                        Cmd("Copy Assembly Between Drawings (Safe)", "CE_ASSEMBLYCOPYSAFE ", "Clone an assembly between open drawings without using the clipboard, which can freeze Civil 3D."),
                        Cmd("Assembly Register", "CE_ASSEMBLYREPORT ", "Review every assembly, style and subassembly count."),
                        Cmd("Assign Design Profiles to Corridors", "CE_CORRIDORPROFILESMULTI ", "Assign multiple design profiles or add selected baselines to multiple corridors."),
                        Cmd("Project Style Centre", "CE_PROJECTSTYLES ", "Select the project assembly, corridor and code-set styles."),
                        Cmd("Create Road Corridors", "CE_ROADCORRIDORS ", "Create corridors using CE road alignment/profile pairs and the selected assembly."))));
        }

        private static void AddRoadProductionPanel(RibbonTab tab)
        {
            AddPanel(
                tab,
                RoadProductionPanelId,
                "ROAD PRODUCTION",
                Row(
                    Menu(
                        "CE_TOOLS_ROAD_PRODUCTION_MENU",
                        "Road\nProduction",
                        "Create road alignments, profiles, assemblies and corridors in engineering workflow order.",
                        Cmd("Road Production Workflow", "CE_ROADPRODUCTION ", "Open the complete ordered road-production window."),
                        Cmd("Road / Utility Route Planner", "CE_ROUTEPLANNER ", "Generate road-reserve and midblock preliminary routes before native Civil 3D production."),
                        Cmd("Preliminary Road Layout Production", "CE_ROADLAYOUTTOOLS ", "Create road-reserve centrelines, road edges, shoulders, bulk T/cross junctions, road names, dimensions and junction setting-out."),
                        Cmd("Create Road Alignments", "CE_ROADALIGN ", "Create sequential linked road alignments from selected polylines."),
                        Cmd("Create Road Profiles", "CE_ROADPROFILES ", "Create existing-ground profiles and ordered profile views."),
                        Cmd("Complete Final Road Profile", "CE_ROADPROFILEFULL ", "Create EG profile/profile view, editable final design profile and parabolic vertical curves."),
                        Cmd("Add / Repair Vertical Curves", "CE_ROADVERTICALCURVES ", "Add symmetric parabolic vertical curves to eligible final-road PVIs."),
                        Cmd("Trim Edges to Bellmouths", "CE_BELLMOUTHTRIMEDGES ", "Trim multiple road/shoulder edges to corrected bellmouth tangent points."),
                        Cmd("Create CE Road Assembly", "CE_ASSEMBLYCREATE ", "Create the Civil 3D assembly used by road corridor regions."),
                        Cmd("Copy Assembly Between Drawings (Safe)", "CE_ASSEMBLYCOPYSAFE ", "Clone an assembly between open drawings without clipboard copy/paste."),
                        Cmd("Create Road Corridors", "CE_ROADCORRIDORS ", "Create one source-preserving corridor for each CE road alignment/profile pair."),
                        Cmd("Complete Road Corridors", "CE_ROADCORRIDORCOMPLETE ", "Apply supported regions, frequencies, targets, surfaces, boundaries, visibility and automatic rebuild settings."),
                        Cmd("Merge CE Road / Final Surfaces", "CE_ROADSURFACEMERGE ", "Create CE Top All, CE Bottom All or CE Final Surface from selected road and grading surfaces."),
                        Cmd("Road Production Information", "CE_ROADPRODUCTIONINFO ", "Review road alignments, profiles, corridors and styles."),
                        Cmd("Road BOQ", "CE_BOQROAD ", "Create the road bill of quantities."),
                        Cmd("Road Design Report", "CE_REPORTROAD ", "Generate the road design report."))));
        }

        private static void AddProjectPanel(RibbonTab tab)
        {
            AddPanel(
                tab,
                ProjectPanelId,
                "Project",
                Row(
                    Menu(
                        "CE_TOOLS_PROJECT_MENU",
                        "Project\nSetup",
                        "Create, review, clear and restore portable project information.",
                        Cmd("CE Tools Home", "CE_WELCOME ", "Open the CE Tools welcome screen with Production Centre and Engineering Intelligence Centre."),
                        Cmd("Phase 1 Utilities", "CE_PHASE1 ", "Open every original CE Tools Phase 1 utility family in one visual hub."),
                        Cmd("Project Coordination", "CE_PROJECTCOORDINATION ", "Coordinate discipline XREFs, paper-space page setups and survey/map location tools."),
                        Cmd("Cadastral Utility Planner", "CE_UTILITYPLANNER ", "Prepare linked cadastral utility routes, constraints, planning manhole points and downstream Sewer/SW/Water workflows."),
                        Cmd("Project Setup", "CE_PROJECTSETUP ", "Create or update project metadata and review it in a pop-up."),
                        Cmd("Project Information", "CE_PROJECTINFO ", "Review project metadata and optionally place a drawing table."),
                        Cmd("Clear Project Information", "CE_PROJECTCLEAR ", "Clear project metadata after confirmation and keep a recoverable backup."),
                        Cmd("Restore Cleared Information", "CE_PROJECTRESTORE ", "Restore the values saved before the last project clear."),
                        Cmd("Drawing and Client Books", "CE_BOOKTOOLS ", "Open drawing-book/client-book production from any discipline."),
                        Cmd("PDF to DWG", "CE_PDFTODWG ", "Create a new DWG from a selected PDF page using AutoCAD native PDFIMPORT.")),
                    Menu(
                        "CE_TOOLS_COORDSYS_MENU",
                        "Coordinate\nSystems",
                        "Report, search, assign and clear the drawing coordinate system.",
                        Cmd("Coordinate System Tools", "CE_COORDSYS ", "Open the coordinate-system menu."),
                        Cmd("Survey Location and Coordinate System", "CE_SURVEYLOCATION ", "Choose a Namibian project town and assign the matching installed Autodesk LO system when available."),
                        Cmd("Latitude / Longitude Map Tools", "CE_MAPLOCATION ", "Open/convert WGS84 and drawing coordinates without changing drawing geometry."),
                        Cmd("Coordinate Transformation", "CE_COORDTRANSFORM ", "Transform drawing XY to WGS84 latitude/longitude and vice versa through the DWG geographic transformation."),
                        Cmd("Bulk Coordinate Conversion", "CE_COORDTRANSFORMBULK ", "Convert CSV/XLSX survey coordinate lists to/from WGS84 using the active DWG."),
                        Cmd("Information", "CE_COORDSYSINFO ", "Report the current coordinate system."),
                        Cmd("Assign", "CE_COORDSYSASSIGN ", "Open Autodesk's native coordinate-system selection window."),
                        Cmd("Assign by Code", "CE_COORDSYSCODE ", "Advanced direct assignment using a validated Autodesk code."),
                        Cmd("Search Library", "CE_COORDSYSSEARCH ", "Search the installed coordinate-system library."),
                        Cmd("Clear", "CE_COORDSYSCLEAR ", "Clear the assignment after confirmation.")),
                    Menu(
                        "CE_TOOLS_STANDARDS_MENU",
                        "Project\nStandards",
                        "Select a standards source file and record its project information.",
                        Cmd("Standards Tools", "CE_STANDARDS ", "Open the standards menu."),
                        Cmd("Select Standards", "CE_STANDARDSELECT ", "Browse for a standards file, review it and save its traceable details."),
                        Cmd("Standards Information", "CE_STANDARDINFO ", "Review stored standards and optionally place a drawing table."),
                        Cmd("Clear Standards", "CE_STANDARDCLEAR ", "Clear the standards record.")),
                    Menu(
                        "CE_TOOLS_PROJECT_STYLES_MENU",
                        "Project\nStyles",
                        "Select and review project Civil 3D styles by discipline.",
                        Cmd("Import Source Styles", "CE_PROJECTSTYLEIMPORT ", "Import Civil 3D styles from the three supplied source drawings or another DWG/DWT."),
                        Cmd("Project Style Centre", "CE_PROJECTSTYLES ", "Select alignment, profile, corridor, point and network styles."),
                        Cmd("Discipline Style Presets", "CE_DISCIPLINESTYLEPRESETS ", "Store and activate independent Roads/SW/Sewer/Water/Platform style selections from the shared style library."),
                        Cmd("Project Style Information", "CE_PROJECTSTYLEINFO ", "Review stored project style selections."),
                        Cmd("Save Project Styles for Other Drawings", "CE_PROJECTSTYLESAVE ", "Save the current discipline selections as the reusable CE project preset."),
                        Cmd("Apply Saved Project Styles", "CE_PROJECTSTYLEAPPLY ", "Apply the reusable saved project styles to the active drawing."),
                        Cmd("Clear Project Styles", "CE_PROJECTSTYLECLEAR ", "Clear only the stored project style selections.")),
                    Menu(
                        "CE_TOOLS_UNDO_MENU",
                        "Undo &\nRedo",
                        "Enable full native undo recording and run one-step undo or redo.",
                        Cmd("Enable Full Undo Recording", "CE_UNDOSETTINGS ", "Enable AutoCAD full undo recording."),
                        Cmd("Undo One Step", "CE_UNDO ", "Run one native AutoCAD undo step."),
                        Cmd("Redo One Step", "CE_REDO ", "Run one native AutoCAD redo step.")),
                    Menu(
                        "CE_TOOLS_COMMAND_CATALOGUE_MENU",
                        "Command\nCatalogue",
                        "Search, audit and export every command declared by CE Tools.",
                        Cmd("Open All Commands", "CE_COMMANDCENTER ", "Open the searchable all-command workflow centre."),
                        Cmd("Command Report", "CE_COMMANDREPORT ", "Review every command, module and ribbon assignment."),
                        Cmd("Command Audit", "CE_COMMANDAUDIT ", "Audit unique declarations and ribbon coverage."),
                        Cmd("Export Command CSV", "CE_COMMANDEXPORT ", "Export the command catalogue to CSV."),
                        Cmd("Export Searchable HTML", "CE_COMMANDHTML ", "Create a searchable offline command reference."),
                        Cmd("Refresh Ribbon and Catalogue", "CE_RIBBONREFRESH ", "Rebuild the CE Tools ribbon and reload the command catalogue.")),
                    Menu(
                        "CE_TOOLS_SETTINGS_CENTRE_MENU",
                        "Settings &\nRelease",
                        "Open all configuration workflows and verify the exact installed release.",
                        Cmd("Settings Centre", "CE_SETTINGS ", "Open every discipline configuration workflow in one searchable window."),
                        Cmd("Saved vs Drawing Settings", "CE_SETTINGSMODE ", "Choose Keep existing drawing settings or Use saved project settings for popup workflows."),
                        Cmd("Settings Coverage Audit", "CE_SETTINGSAUDIT ", "Review the configuration workflows exposed by the settings centre."),
                        Cmd("Installed Version", "CE_VERSION ", "Review the loaded assembly, source commit and bundle identity."),
                        Cmd("Verify Installation", "CE_INSTALLVERIFY ", "Verify packaged files against the installed SHA-256 release manifest."),
                        Cmd("Check for Updates", "CE_UPDATECHECK ", "Compare the installed assembly with the latest packaged GitHub release."))));
        }

        private static void AddSurveyPanel(RibbonTab tab)
        {
            AddPanel(
                tab,
                SurveyPanelId,
                "Survey",
                Row(
                    Menu(
                        "CE_TOOLS_SURVEY_MENU",
                        "Coordinate\nTools",
                        "Linked coordinate labels, COGO points, crosses, compact tables and polyline vertices.",
                        Cmd("Linked Picked Coordinate", "CE_COORDPICK2 ", "Create a coordinate annotation and optionally add its source point to a linked register."),
                        Cmd("Continuous Linked Coordinates", "CE_COORDPICKCONTINUOUS ", "Place sequential linked coordinate outputs continuously."),
                        Cmd("Linked Coordinate Cross", "CE_COORDCROSS2 ", "Choose COGO point, cross, annotation and linked register output."),
                        Cmd("Create Linked Coordinate Table", "CE_COORDTABLE2 ", "Create a compact linked Y-X-Z table from selected COGO or AutoCAD points."),
                        Cmd("Refresh Linked Coordinate Table", "CE_COORDREFRESH ", "Refresh table rows from the current linked source-point coordinates."),
                        Cmd("Polyline Vertex Linked Points", "CE_COORDPOLY2 ", "Open the same dynamic vertex setting-out popup in vertices-only mode."),
                        Cmd("Multi-Source Vertex Setting-Out", "CE_VERTEXSETTINGOUT ", "Create dynamic COGO, MText or MLeader points from multiple polylines and feature lines, including arc centres and long-segment points."),
                        Cmd("Refresh Vertex Setting-Out", "CE_VERTEXSETTINGOUTREFRESH ", "Recalculate linked vertex points, names, coordinates, radius dimensions and table rows."),
                        Cmd("Export Vertex Setting-Out", "CE_VERTEXSETTINGOUTEXPORT ", "Refresh and export a linked vertex setting-out table to Excel."),
                        Cmd("Synchronize COGO Project Styles", "CE_COGOPOINTSYNC ", "Apply RSA_Circle/Description Only or the saved Project Style Centre point choices to every COGO point."),
                        Cmd("Resolve COGO Label Overlaps", "CE_COGOOVERLAPFIX ", "Move COGO labels only while keeping survey point coordinates fixed."),
                        Cmd("Repair All Linked Annotations", "CE_ANNOTATIONLINKREPAIR ", "Refresh and re-anchor COGO, MText, MLeader, tables and radius dimensions close to their true source points."),
                        Cmd("Convert Curves and Polylines", "CE_CURVECONVERT ", "Convert lines, arcs, circles, splines, lightweight and 3D polylines through one popup.")),
                    Menu(
                        "CE_TOOLS_SURVEY_UTILITIES_MENU",
                        "Survey\nUtilities",
                        "Direction arrows and preserved coordinate workflows.",
                        Cmd("Polyline Direction Arrows", "CE_PLDIR ", "Add, replace or clear linked arrows showing stored polyline direction."),
                        Cmd("Refresh Direction Arrows", "CE_PLDIRREFRESH ", "Reposition linked arrows after polyline edits."),
                        Cmd("Reverse Polyline and Arrows", "CE_PLDIRREVERSE ", "Reverse selected polylines and their linked arrows."),
                        Cmd("Break at Crossings and Junctions", "CE_PLBREAKJUNCTIONS ", "Break selected network polylines at every true crossing and T-junction."),
                        Cmd("Presentation and Dynamic Refresh", "CE_PRESENTATIONTOOLS ", "Open shared annotation, overlap and rebuild workflows."),
                        Cmd("Survey Cleanup", "CE_SURVEYCLEANUP ", "Review correction surfaces, coordinate links and controlled cleanup workflows."),
                        Cmd("Coordinate Utilities", "CE_COORDINATE ", "Open coordinate labels, crosses and tables."),
                        Cmd("Point / Circle Conversion", "CE_POINTCIRCLE ", "Convert survey points to circles or circle centres to styled COGO points."),
                        Cmd("Grid Setting-Out", "CE_GRIDSETTINGOUT ", "Create unique perimeter/full-grid COGO setting-out points."),
                        Cmd("Namibia LO / WGS84 Conversion", "CE_NAMIBIALO ", "Convert correct Schwarzeck Lo22 survey Y/X coordinates, decimal/DMS WGS84 and drawing XY."),
                        Cmd("Pick Point Coordinate Review", "CE_COORDPICKMAP ", "Pick any drawing point and review drawing XY, LO and WGS84 values."),
                        Cmd("LandXML Import / Export", "CE_LANDXMLTOOLS ", "Open Civil 3D native LandXML import/export workflows."),
                        Cmd("Annotation Scale Sync", "CE_ANNOTATIONSCALESYNC ", "Synchronize CE annotation objects/tables to the current annotation scale."),
                        Cmd("Picked Coordinate Annotation (Legacy)", "CE_COORDPICKX ", "Create the Batch 3 coordinate annotation workflow."),
                        Cmd("Coordinate Cross + Annotation (Legacy)", "CE_COORDCROSSX ", "Create the Batch 3 cross and annotation workflow."),
                        Cmd("Polyline Vertex COGO Points (Legacy)", "CE_COORDPOLY ", "Run the original sequential COGO point and XYZ table workflow."))));
        }

        private static void AddDrawingsPanel(RibbonTab tab)
        {
            AddPanel(
                tab,
                DrawingsPanelId,
                "Drawings",
                Row(
                    Menu(
                        "CE_TOOLS_DRAWING_MENU",
                        "Drawing\nTools",
                        "AutoCAD drawing and annotation utilities.",
                        Cmd("Open Workflow Centre", "CE_TOOLSPALETTE ", "Open every ribbon workflow and searchable command in the floating window."),
                        Cmd("Create Coordinated Master XREF Drawing", "CE_MASTERXREF ", "Create a new non-destructive master DWG referencing Roads, Stormwater, Sewer and Water source drawings at the same origin."),
                        Cmd("Multi-Layout Page Setup Manager", "CE_PAGESETUPMANAGER ", "Copy one paper-space layout page setup to multiple layouts in a popup workflow."),
                        Cmd("Phase 1 Utilities", "CE_PHASE1 ", "Open the completed Phase 1 utility hub."),
                        Cmd("Label Utilities", "CE_LABELTOOLS ", "Open coordinate, alignment, profile, surface, feature-line, corridor and parking labels."),
                        Cmd("Viewport Tools", "CE_VIEWPORTTOOLS ", "Report, lock or unlock paper-space viewports."),
                        Cmd("Layer Manager", "CE_LAYERTOOLS ", "Audit drawing layers or open AutoCAD Layer Properties."),
                        Cmd("Excel Tools", "CE_EXCELTOOLS ", "Open linked BOQ, setting-out, survey and report exports."),
                        Cmd("Annotation Settings", "CE_ANNOTSETTINGS ", "Select 1.8, 2.0, 2.5, 3.5 or 5.0 mm height, marker and MLeader/MText/COGO output."),
                        Cmd("Make Objects Annotative", "CE_MAKEANNOTATIVE ", "Apply CE annotative settings to selected supported objects."),
                        Cmd("Synchronize Annotation Scale", "CE_ANNOSCALESYNC ", "Add the current annotation scale to supported objects."),
                        Cmd("Scale Selected Tables", "CE_TABLESCALE ", "Resize selected tables relative to CE text height."),
                        Cmd("Resolve Annotation Overlaps", "CE_OVERLAPFIX ", "Reposition supported annotations to reduce overlap."),
                        Cmd("Change Objects to Colour 250", "CE_COLOR250 ", "Change selected objects to colour 250."),
                        Cmd("Polyline Direction Arrows", "CE_PLDIR ", "Add, replace or clear linked direction arrows."),
                        Cmd("Final Comment Closure Centre", "CE_COMMENTCLOSURE ", "Open overlap/restore, table navigation, interoperability, settings and final refresh tools."),
                        Cmd("Smart Annotation Overlap", "CE_OVERLAPSMART ", "Resolve only conflicting annotations with All/Selected scope and restorable original positions."),
                        Cmd("Restore Annotation Positions", "CE_ANNOTATIONRESTORE ", "Restore all/selected CE-overlap annotation positions."),
                        Cmd("Annotation Draw Order", "CE_ANNOTATIONDRAWORDER ", "Bring supported design labels to front or send them to back."),
                        Cmd("Export Civil Design to CAD Copy", "CE_EXPORTCADCOPY ", "Create a separate AutoCAD-compatible copy without changing the current design drawing."),
                        Cmd("Multiple Boundary Trim / Extend", "CE_BOUNDARYEDITTOOLS ", "Trim, trim-and-delete or extend all/selected drawing curves against multiple closed boundaries.")),
                    Menu(
                        "CE_TOOLS_CLEANUP_MENU",
                        "Cleanup\nManager",
                        "Run OVERKILL, AUDIT and PURGE together or separately.",
                        Cmd("Cleanup Window", "CE_DRAWCLEAN ", "Choose cleanup stages in a visual window."),
                        Cmd("Full Cleanup", "CE_DRAWCLEANALL ", "Run all drawing-cleanup stages."),
                        Cmd("OVERKILL Only", "CE_DRAWOVERKILL ", "Remove duplicate and overlapping geometry."),
                        Cmd("AUDIT Only", "CE_DRAWAUDIT ", "Audit and fix drawing errors."),
                        Cmd("PURGE Only", "CE_DRAWPURGE ", "Purge unused named objects.")),
                    Menu(
                        "CE_TOOLS_HATCH_MENU",
                        "Hatch\nTools",
                        "Create and edit transparent civil hatches while keeping grids, labels and linework visible.",
                        Cmd("Hatch Tools", "CE_HATCHTOOLS ", "Open the CE hatch tools menu."),
                        Cmd("Create Transparent Hatches", "CE_HATCHCREATE ", "Create associative hatches from selected closed boundaries."),
                        Cmd("Edit Hatch Settings", "CE_HATCHEDIT ", "Edit selected hatch pattern, scale, angle, colour and transparency."),
                        Cmd("Match Hatch Settings", "CE_HATCHMATCH ", "Copy hatch display settings from one source hatch."),
                        Cmd("Send Hatches Behind Linework", "CE_HATCHBACK ", "Move selected hatches to the back of draw order."))));
        }

        private static void AddGeometryPanel(RibbonTab tab)
        {
            AddPanel(
                tab,
                GeometryPanelId,
                "Geometry",
                Row(
                    Menu(
                        "CE_TOOLS_ROADS_MENU",
                        "Road\nTools",
                        "Road geometry utilities.",
                        Cmd("Bellmouth Densifier", "CE_BMVERT ", "Add equal-chainage vertices to bellmouth polylines."),
                        Cmd("Reverse Multiple Alignments + Profiles", "CE_ROADALIGNREVERSEMULTI ", "Reverse selected road alignments and refresh their profiles, profile views and corridors."),
                        Cmd("Batch T/Cross Bellmouths", "CE_ROADJUNCTIONBATCH ", "Create all T/cross bellmouth returns, magenta closure/assembly-limit lines and optional feature-line output."),
                        Cmd("T-Junction Assembly Limits", "CE_ROADTJUNCTIONASSEMBLYLIMITS ", "Trim only T-junction side-road terminal corridor regions at the generated magenta limits."),
                        Cmd("Road TOP/BOTTOM Surface Names", "CE_ROADSURFACENAMES ", "Normalize corridor surfaces to TOP-RD-01/BOTTOM-RD-01 naming."),
                        Cmd("TOP/BOTTOM Surfaces in Profile Views", "CE_ROADTOPBOTTOMPROFILE ", "Add road TOP/BOTTOM surfaces to selected profile views at crossing coverage."),
                        Cmd("Junction End Points to TOP Surfaces", "CE_JUNCTIONENDPOINTSTOTOPSURFACES ", "Add junction return and closure endpoints to covering road TOP surfaces."),
                        Cmd("Road Settings", "CE_ROADSETTINGS ", "Choose road-only alignment, profile, profile-view band-set, corridor, code-set and assembly styles.")),
                    Menu(
                        "CE_TOOLS_FEATURE_LINE_MENU",
                        "Feature Line\nTools",
                        "Feature-line creation, reporting, editing, annotation and linked stepped offsets.",
                        Cmd("Feature Line Tools", "CE_FLTOOLS ", "Open feature-line report and elevation workflows."),
                        Cmd("Report", "CE_FLREPORTUI ", "Show feature-line details in a pop-up and optionally place a table."),
                        Cmd("Feature Line Annotation", "CE_FLLABELX ", "Create a feature-line MLeader, MText or COGO point using shared settings."),
                        Cmd("Dynamic Vertex Points and Table", "CE_FLVERTEXLABELS ", "Create linked feature-line vertex COGO/MText/MLeader points and an optional dynamic XYZ table."),
                        Cmd("Raise / Lower", "CE_FLRAISEX ", "Explicitly edit selected feature-line elevations after a before/after review."),
                        Cmd("Raise / Lower (Legacy)", "CE_FLRAISE ", "Run the original feature-line elevation editing command."),
                        Cmd("Set Elevation", "CE_FLSETELEV ", "Set selected feature lines to one elevation."),
                        Cmd("Constant Grade Between Endpoints", "CE_FLCONSTGRADE ", "Set all existing points to a constant grade between each feature line's endpoint elevations."),
                        Cmd("Create and Point Edit", "CE_FLEDIT ", "Open creation, surface and point-edit tools."),
                        Cmd("Create from Object", "CE_FLCREATE ", "Create feature lines from supported curves."),
                        Cmd("Add Feature Lines as Surface Breaklines", "CE_FLBREAKLINE ", "Add selected feature lines/3D curves to a Civil 3D TIN surface as standard breaklines."),
                        Cmd("Elevations from Surface", "CE_FLSURFACEUI ", "Select a Civil 3D surface from a pop-up and assign feature-line elevations."),
                        Cmd("Elevations from Surface (Legacy)", "CE_FLSURFACE ", "Run the original command-line surface assignment workflow."),
                        Cmd("Insert Elevation Point", "CE_FLINSERT ", "Insert an elevation point."),
                        Cmd("Delete Elevation Point", "CE_FLDELETE ", "Delete a confirmed elevation point."),
                        Cmd("Weed Elevation Points", "CE_FLWEED ", "Remove redundant elevation points."),
                        Cmd("Linked Stepped Offset", "CE_FLREL ", "Create, update, inspect or detach linked stepped offsets."),
                        Cmd("Create Linked Offset Set", "CE_FLRELCREATE ", "Create multiple stepped offsets linked to one source feature line with automatic refresh."),
                        Cmd("Heal Stepped Feature Lines", "CE_FLSTEPJOIN ", "Close small endpoint gaps and create one feature line while preserving piece endpoints as vertices."),
                        Cmd("Update Linked Offset Set", "CE_FLRELUPDATE ", "Select the source or any child and immediately refresh the complete linked offset set."),
                        Cmd("Update Multiple Offset Sets", "CE_FLRELUPDATEMULTI ", "Select multiple source feature lines or linked children and rebuild only those stepped-offset sets."),
                        Cmd("Linked Offset Information", "CE_FLRELINFO ", "Report a linked offset relationship."),
                        Cmd("Detach Linked Offset", "CE_FLRELDETACH ", "Keep geometry but remove the CE relationship.")),
                    Menu(
                        "CE_TOOLS_ALIGNMENT_MENU",
                        "Alignment\nTools",
                        "Alignment reporting, station-offset queries and labels.",
                        Cmd("Alignment Tools", "CE_ALTOOLS ", "Open alignment tools."),
                        Cmd("Alignment Report", "CE_ALREPORTUI ", "Show alignment details in a pop-up and optionally place a table."),
                        Cmd("Station and Offset", "CE_ALSTOFF ", "Report station and signed offset."),
                        Cmd("Station-Offset Annotation", "CE_ALLABELX ", "Create an MLeader, MText or COGO point using shared annotation settings.")),
                    Menu(
                        "CE_TOOLS_PROFILE_MENU",
                        "Profile\nTools",
                        "Profile reporting, station elevations and plan labels.",
                        Cmd("Profile Tools", "CE_PRTOOLS ", "Open profile tools."),
                        Cmd("Batch Profile Views", "CE_PROFILEVIEWBATCHTOOLS ", "Apply profile-view styles, band sets, automatic fit and rebuild options."),
                        Cmd("Edit One Profile View + Apply to Selected", "CE_PROFILEVIEWEDITMATCH ", "Open native Profile View Properties for one source view, edit it once, then automatically copy the edited style/ranges/bands to all selected target views with target-specific profile/network sources."),
                        Cmd("Match Profile View Properties", "CE_PROFILEVIEWMATCH ", "Use one source profile view to match styles, ranges, complete band rows, labels and data-source assignments to multiple targets."),
                        Cmd("Band Data Sources (Multiple Views)", "CE_PROFILEVIEWDATASOURCES ", "Apply Profile 1/Profile 2/Pipe Network data sources to compatible band items on multiple profile views."),
                        Cmd("Safe Profile / Band Batch", "CE_PROFILEBATCHSAFE ", "Run profile style/band repair stages independently to isolate incompatible profile views."),
                        Cmd("Profile Report", "CE_PRREPORTUI ", "Show profile details in a pop-up and optionally place a table."),
                        Cmd("Station Elevation", "CE_PRELEV ", "Report elevation and grade at a station."),
                        Cmd("Profile Annotation", "CE_PRLABELX ", "Create an MLeader, MText or COGO point using shared annotation settings.")),
                    Menu(
                        "CE_TOOLS_SURFACE_MENU",
                        "Surface\nTools",
                        "Surface reporting, elevation labels and comparisons.",
                        Cmd("Surface Tools", "CE_SFTOOLS ", "Open surface tools."),
                        Cmd("Surface Report", "CE_SFREPORTUI ", "Show surface details in a pop-up and optionally place a table."),
                        Cmd("Surface Elevation", "CE_SFELEV ", "Report an elevation at a point."),
                        Cmd("Surface Annotation", "CE_SFLABELX ", "Create an MLeader, MText or COGO point using shared annotation settings."),
                        Cmd("Compare Surfaces", "CE_SFCOMPARE ", "Compare two surface elevations.")),
                    Menu(
                        "CE_TOOLS_SURFACE_CORRECTION_MENU",
                        "Surface\nCorrection",
                        "Audit, repair and simplify surfaces through reversible generated copies.",
                        Cmd("Surface Correction Tools", "CE_SURFCTOOLS ", "Open correction, audit, simplify, restore, settings and information workflows."),
                        Cmd("Audit Surface Quality", "CE_SURFAUDIT ", "Screen for spikes, lows, holes and likely contamination."),
                        Cmd("Create Reversible Corrected Surface", "CE_SURFCORRECT ", "Create a separate corrected copy without editing the source."),
                        Cmd("Create Reversible Simplified Surface", "CE_SURFSIMPLIFY ", "Create a separate performance copy."),
                        Cmd("Restore / Remove Generated Copy", "CE_SURFCRESTORE ", "Remove only a CE-generated surface copy."),
                        Cmd("Surface Correction Settings", "CE_SURFCSETTINGS ", "Configure audit and correction thresholds."),
                        Cmd("Surface Correction Information", "CE_SURFCINFO ", "Review generated surface links and settings."),
                        Cmd("Spike and Hole Repair", "CE_SURFSPIKEHOLEFIX ", "Create a repaired surface while keeping the original unchanged.")),
                    Menu(
                        "CE_TOOLS_DYNAMIC_INTERSECTION_MENU",
                        "Dynamic\nIntersections",
                        "Create and maintain linked plan intersection sets.",
                        Cmd("Dynamic Intersection Tools", "CE_INTTOOLS ", "Open intersection create, refresh, information, detach, settings and monitor workflows."),
                        Cmd("Create Linked Intersection Set", "CE_INTCREATE ", "Create linked markers and elevation comparisons."),
                        Cmd("Refresh Linked Intersection Set", "CE_INTREFRESH ", "Refresh a linked set from current geometry."),
                        Cmd("Intersection Set Information", "CE_INTINFO ", "Review sources, generated handles and monitor status."),
                        Cmd("Detach Intersection Set", "CE_INTDETACH ", "Remove the link and keep or delete generated geometry."),
                        Cmd("Dynamic Intersection Settings", "CE_INTSETTINGS ", "Configure marker, tolerance, sampling and corridor-code settings."),
                        Cmd("Dynamic Intersection Monitor", "CE_INTMONITOR ", "Review linked sets and deferred refresh state."))));
        }

        private static void AddCorridorPanel(RibbonTab tab)
        {
            AddPanel(
                tab,
                CorridorPanelId,
                "Corridors",
                Row(Menu(
                    "CE_TOOLS_CORRIDOR_MENU",
                    "Corridor\nTools",
                    "Corridor reporting, annotation, baseline inspection and rebuilding.",
                    Cmd("Corridor Tools", "CE_CORTOOLS ", "Open the legacy corridor tools menu."),
                    Cmd("Corridor Report", "CE_CORREPORTUI ", "Show corridor details in a pop-up and optionally place a table."),
                    Cmd("Create / Rebuild Baselines and Regions", "CE_ROADCORRIDORCOMPLETE ", "Create or rebuild corridor baselines, regions, targets and corridor surfaces as one production step."),
                    Cmd("Baseline / Region Report", "CE_CORBASEUI ", "Show baseline and region details in a pop-up and optionally place a table."),
                    Cmd("Extract Corridor Feature Lines", "CE_CORRIDORFEATURELINES ", "Export selected corridor feature lines as dynamic links or normal independent feature lines, with site and weeding controls."),
                    Cmd("Dynamic Corridor Annotation", "CE_CORLABELX ", "Create a linked MLeader, MText or COGO corridor annotation with selectable paper height and an optional circle at the reference/leader start."),
                    Cmd("Rebuild Corridors", "CE_CORREBUILDX ", "Explicitly call Corridor.Rebuild() for every editable selected corridor after review."),
                    Cmd("Rebuild Corridors (Legacy)", "CE_CORREBUILD ", "Run the original controlled rebuild command."))));
        }

        private static void AddSiteDesignPanel(RibbonTab tab)
        {
            AddPanel(
                tab,
                SiteDesignPanelId,
                "Site Design",
                Row(
                    Menu(
                        "CE_TOOLS_PLATFORM_PRODUCTION_MENU",
                        "Platform\nProduction",
                        "Create linked platform feature lines, slopes, stepped offsets, surfaces, setting-out, quantities and drawings.",
                        Cmd("Platform Production Workflow", "CE_PLATFORMTOOLS ", "Open the complete linked platform-production workflow."),
                        Cmd("Create Feature Lines", "CE_FLCREATE ", "Create feature lines from multiple polylines with popup surface selection."),
                        Cmd("Platform Slopes / Levels", "CE_PLATFORMSLOPE ", "Apply constant high-low slope, fixed slope or flatten to highest elevation."),
                        Cmd("Multiple Stepped Offsets", "CE_PLATFORMSTEPOFFSETS ", "Create linked stepped offsets for multiple platform feature lines."),
                        Cmd("Drape Steps to Surface", "CE_PLATFORMDRAPE ", "Drape linked steps to a selected surface and dynamically drive platform elevations."),
                        Cmd("Merge CE Road / Final Surfaces", "CE_ROADSURFACEMERGE ", "Create CE Top All, CE Bottom All or CE Final Surface from selected natural ground and road/grading surfaces."),
                        Cmd("Platform Site / Surface / Infill", "CE_PLATFORMSURFACE ", "Assign platforms to a site, build a separate surface and create grading infill where supported."),
                        Cmd("Platform Setting-Out", "CE_PLATFORMSETTINGOUT ", "Open vertex and grid setting-out workflows."),
                        Cmd("Platform Names", "CE_PLATFORMNAMES ", "Place PLATFORM-n labels with final platform elevations."),
                        Cmd("Linked Platform Register", "CE_PLATFORMTABLE ", "Create a linked annotative platform area/elevation register."),
                        Cmd("Platform Cut / Fill", "CE_PLATFORMCUTFILL ", "Create linked NG-versus-design cut/fill quantities."),
                        Cmd("Platform Drawings / Sections", "CE_PLATFORMDRAWINGS ", "Create platform layouts and section source lines."),
                        Cmd("Refresh Linked Platforms", "CE_PLATFORMREFRESH ", "Refresh surface links, stepped offsets, labels and tables.")),
                    Menu(
                        "CE_TOOLS_GRADING_SLOPES_MENU",
                        "Grading &\nSlopes",
                        "Platform grading, cut/fill daylight, constant grades, dynamic slope/crossfall annotation and grading diagnostics.",
                        Cmd("Grading & Slopes", "CE_GRADINGSLOPETOOLS ", "Open the combined grading and slope workflow."),
                        Cmd("Grade Feature Lines to Surface", "CE_PLATFORMGRADETOSURFACE ", "Create dynamic cut/fill daylight grading with separate cut and fill H:V slopes."),
                        Cmd("Constant Grade Between Endpoints", "CE_PLATFORMCONSTANTGRADE ", "Grade multiple open feature lines between fixed endpoint elevations."),
                        Cmd("Platform Slopes / Levels", "CE_PLATFORMSLOPE ", "Apply platform level and slope options."),
                        Cmd("Feature-Line Slope Arrows", "CE_FEATURELINESLOPEARROWS ", "Create linked slope arrows and percentage values along feature lines."),
                        Cmd("Crossfall Between Feature Lines", "CE_FEATURELINECROSSFALLARROWS ", "Create linked crossfall arrows and slope values between two feature lines."),
                        Cmd("Surface Slope Arrows", "CE_SURFACESLOPEARROWS ", "Create slope arrows and values sampled from a Civil 3D surface."),
                        Cmd("Refresh Feature-Line Slope Arrows", "CE_SLOPEARROWSREFRESH ", "Refresh linked feature-line slope annotations."),
                        Cmd("Refresh Dynamic Crossfalls", "CE_DYNAMICSLOPESREFRESH ", "Refresh linked crossfall/dynamic slope annotations."),
                        Cmd("Grading Diagnostics", "CE_GRADINGDIAGNOSTICS ", "Review low slopes and low points."),
                        Cmd("Find Low Slopes", "CE_LOWSLOPE ", "Highlight geometry below the selected minimum slope."),
                        Cmd("Find Low Points", "CE_LOWPOINTS ", "Mark candidate grading low points."),
                        Cmd("Platform Cut / Fill", "CE_PLATFORMCUTFILL ", "Calculate linked existing-ground versus design cut/fill quantities.")),
                    Menu(
                        "CE_TOOLS_PARKING_MENU",
                        "Parking\nTools",
                        "Parking layout, reporting, numbering and boundary-driven options.",
                        Cmd("Parking Tools", "CE_PKTOOLS ", "Open legacy parking tools."),
                        Cmd("Single Row", "CE_PKROW ", "Create a straight single row."),
                        Cmd("Double Row", "CE_PKDOUBLE ", "Create opposing rows around an aisle."),
                        Cmd("Parking Report", "CE_PKREPORTUI ", "Show parking bay groups in a pop-up."),
                        Cmd("Validate and Count Bays", "CE_PKCOUNTX ", "Validate and count block or closed-polyline bays."),
                        Cmd("Validate and Number Bays", "CE_PKNUMBER2 ", "Validate and number accepted bays."),
                        Cmd("Number Bays (Legacy Shared)", "CE_PKNUMBERX ", "Run the preserved shared-height parking numbering workflow."),
                        Cmd("Refresh Linked Parking Numbers", "CE_PKNUMBERREFRESH ", "Refresh labels after bay edits."),
                        Cmd("Dynamic Parking Options", "CE_PARKOPTIONS ", "Generate linked parking inside a selected boundary."),
                        Cmd("Refresh Dynamic Parking", "CE_PARKOPTIONSREFRESH ", "Rebuild linked parking after boundary edits."),
                        Cmd("Parking Option Information", "CE_PARKOPTIONSINFO ", "Review linked capacity and sources."),
                        Cmd("Clear Dynamic Parking", "CE_PARKOPTIONSCLEAR ", "Remove generated bays while retaining the boundary.")),
                    Menu(
                        "CE_TOOLS_PARKING_GRADING_MENU",
                        "Parking\nGrading",
                        "Dynamic parking grading and drainage guides.",
                        Cmd("Parking Grading Tools", "CE_PARKGRADETOOLS ", "Open linked parking grading workflows."),
                        Cmd("Create Grading Guides", "CE_PARKGRADECREATE ", "Create linked low-point, crown or valley guides."),
                        Cmd("Refresh Grading Guides", "CE_PARKGRADEREFRESH ", "Rebuild guides from current boundaries."),
                        Cmd("Grading Information", "CE_PARKGRADEINFO ", "Review assumptions and source links."),
                        Cmd("Clear Grading Guides", "CE_PARKGRADECLEAR ", "Remove selected grading guides."),
                        Cmd("Automatic Parking Refresh", "CE_PARKAUTOMONITOR ", "Toggle automatic linked parking refresh."),
                        Cmd("Refresh All Linked Parking", "CE_PARKAUTOREFRESHALL ", "Rebuild every linked parking result."),
                        Cmd("Parking Refresh Status", "CE_PARKAUTOSTATUS ", "Review automatic refresh and pending links.")),
                    Menu(
                        "CE_TOOLS_PARKING_OPTIMIZER_MENU",
                        "Parking\nOptimizer",
                        "Optimize parking layouts around boundaries and obstacles.",
                        Cmd("Parking Optimizer Tools", "CE_PARKOPTIMIZERTOOLS ", "Open optimize, refresh, export, information and clear workflows."),
                        Cmd("Optimize Parking", "CE_PARKOPTIMIZE ", "Generate optimized parking candidates."),
                        Cmd("Refresh Optimized Parking", "CE_PARKOPTREFRESH ", "Recalculate a linked optimized layout."),
                        Cmd("Export Parking Report", "CE_PARKOPTEXPORT ", "Export optimized parking results."),
                        Cmd("Parking Optimizer Information", "CE_PARKOPTINFO ", "Review sources and optimization settings."),
                        Cmd("Clear Optimized Parking", "CE_PARKOPTCLEAR ", "Remove generated optimizer output.")),
                    Menu(
                        "CE_TOOLS_PARKING_SKEW_MENU",
                        "Parking Skew\nValidation",
                        "Validate perpendicular bay width and create correction outlines.",
                        Cmd("Parking Skew Tools", "CE_PKSKTOOLS ", "Open validate, correct, clear, settings and information workflows."),
                        Cmd("Validate Perpendicular Bay Width", "CE_PKSKVALIDATE ", "Measure true perpendicular width."),
                        Cmd("Create Failed-Bay Correction Outlines", "CE_PKSKCORRECT ", "Create target-width outlines without changing source geometry."),
                        Cmd("Clear Skew Review Graphics", "CE_PKSKCLEAR ", "Clear CE skew review graphics."),
                        Cmd("Parking Skew Settings", "CE_PKSKSETTINGS ", "Configure width, tolerance, layers and annotation size."),
                        Cmd("Parking Skew Information", "CE_PKSKINFO ", "Review generated objects and source handles."))));
        }

        private static void AddUtilitiesPanel(RibbonTab tab)
        {
            AddPanel(
                tab,
                UtilitiesPanelId,
                "Utilities",
                Row(
                    Menu(
                        "CE_TOOLS_UTILITY_PLANNER_MENU",
                        "Utility\nPlanning",
                        "Cadastral route preparation, constraints and linked discipline-production handoff.",
                        Cmd("Cadastral Utility Planner", "CE_UTILITYPLANNER ", "Open cadastral route preparation and downstream network workflows."),
                        Cmd("Road / Utility Route Planner", "CE_ROUTEPLANNER ", "Generate preliminary Roads/SW/Sewer/Water/Bulk Water route geometry."),
                        Cmd("Utility Route from Road Reserve", "CE_UTILITYFROMROADRESERVE ", "Create Sewer/SW/Water/Bulk Water routes from connected CE road-reserve centrelines."),
                        Cmd("Multiple Pipe / Structure Tools", "CE_NETWORKMULTI ", "Create, connect and schedule multiple network objects."),
                        Cmd("Create Linked Cadastral Routes", "CE_UTILITYROUTES ", "Create road-reserve/midblock utility planning routes, manhole planning points and a constraint report."),
                        Cmd("Refresh Linked Cadastral Routes", "CE_UTILITYROUTESREFRESH ", "Refresh utility routes from edited source erf/cadastral polylines."),
                        Cmd("Prepare Crossings and Junctions", "CE_PLBREAKJUNCTIONS ", "Break prepared utility polylines at true crossings and T-junctions."),
                        Cmd("Network Creation Hub", "CE_NETWORKCREATEHUB ", "Create Sewer/SW/Water/Bulk Water networks from line/polyline/feature-line objects and connect parts."),
                        Cmd("Batch Networks from Multiple Sources", "CE_NETWORKFROMPOLYLINESBATCH ", "Select multiple source polylines/feature lines once and queue native network creation with duplicate-source protection."),
                        Cmd("Utility Route Offset from Erf / Reserve", "CE_UTILITYROUTEOFFSET ", "Create SW/Sewer/Water/Bulk-Water routes at selected offsets from erf, road-reserve or road-centre geometry."),
                        Cmd("Close / Connect Selected Pipes", "CE_CLOSEPIPESONLY ", "Close/connect selected pipe and structure parts without invoking BOQ refresh."),
                        Cmd("Create Network from Object", "CE_NETWORKFROMPOLYLINES ", "Choose discipline and launch the Civil 3D native network-from-object workflow."),
                        Cmd("Connect Pipe / Structure Parts", "CE_NETWORKCONNECT ", "Launch Civil 3D Connect Network Part To for selected network parts."),
                        Cmd("Auto Connect Open Pipe Ends", "CE_NETWORKCONNECTALL ", "Connect open gravity-pipe ends to nearby structures in the same network within a chosen tolerance.")),
                    Menu(
                        "CE_TOOLS_STORMWATER_MENU",
                        "Stormwater\nProduction",
                        "Sequence networks and create linked alignments and profiles.",
                        Cmd("Stormwater Tools", "CE_SWTOOLS ", "Open the complete stormwater production menu."),
                        Cmd("Sequence Main and Branches", "CE_SWSEQ ", "Sequence the complete stormwater network."),
                        Cmd("Create / Refresh Alignments", "CE_SWALIGN ", "Create linked stormwater alignments."),
                        Cmd("Refresh Alignments", "CE_SWREFRESH ", "Refresh alignments from their sources."),
                        Cmd("Create / Refresh Profiles", "CE_SWPROFILE ", "Create EG profiles and profile views."),
                        Cmd("Stormwater Settings", "CE_SWSETTINGS ", "Configure project styles, layers and labels."),
                        Cmd("Stormwater Information", "CE_SWINFO ", "Review links and current settings.")),
                    Menu(
                        "CE_TOOLS_SEWER_PRODUCTION_MENU",
                        "Sewer Network\nProduction",
                        "Sequence sewer networks, format alignments and create profiles.",
                        Cmd("Sewer Production Tools", "CE_SEWTOOLS ", "Open the complete sewer production menu."),
                        Cmd("Sewer Long Section Bands", "CE_SEWBANDLABELS ", "Apply or repair the selected native sewer band set on multiple profile views, including gravity-network and ground-profile source binding."),
                        Cmd("Sequence Network + Production Options", "CE_SEWSEQWORKFLOW ", "Sequence a complete network or selected path."),
                        Cmd("Sequence Selected Main + Production Options", "CE_SEWSEQMAINWORKFLOW ", "Select Branch-1 and sequence remaining branches."),
                        Cmd("Dynamic Resequence Selected Network", "CE_SEWAUTOSEQ ", "Compact Branch/P/MH numbering after deletions or reconnections and refresh linked outputs."),
                        Cmd("Dynamic Resequence All CE Networks", "CE_SEWAUTOSEQALL ", "Refresh all previously CE-sequenced sewer networks."),
                        Cmd("Dynamic Resequence Settings", "CE_SEWAUTOSEQSETTINGS ", "Enable or disable automatic topology resequencing."),
                        Cmd("Create / Refresh Pipe and Structure Labels", "CE_SEWLABELS ", "Add the selected Civil 3D plan labels without duplicating existing labels."),
                        Cmd("Create / Refresh Alignments", "CE_SEWALIGN ", "Create branch alignments and labels."),
                        Cmd("Refresh Linked Alignments", "CE_SEWREFRESH ", "Refresh from linked source networks."),
                        Cmd("Format Alignments and Labels", "CE_SEWFORMAT ", "Apply styles and improve label spacing."),
                        Cmd("Automatic Civil Label Formatting", "CE_CIVILLABELFORMAT ", "Format alignment, profile, corridor, pipe, structure and CE labels to one paper height."),
                        Cmd("Create Profiles / Long Sections", "CE_SEWPROFILE ", "Create isolated branch profile views, link network parts and band data, and review the long-section register."),
                        Cmd("Integrity / Engineering Audit", "CE_SEWAUDITLIMITS ", "Review open pipe ends, isolated/terminal structures, rule/surface assignments, inverts, cover, slopes, drops, depths and sump clearances without changing the network."),
                        Cmd("Connect Open Pipe Ends", "CE_SEWCONNECTPARTS ", "Connect open pipe starts or ends to nearby existing structures in the same gravity network."),
                        Cmd("Flow Toward Selected Outlet / Low Point", "CE_SEWFLOWTOOUTLET ", "Use the connected structure/pipe sequence to set every gravity pipe flow direction toward one selected downstream structure without moving endpoints or changing rule sets."),
                        Cmd("Show Manhole Pipe Connections", "CE_SEWINCOMINGPIPES ", "Show all connected pipe openings and list incoming/outgoing invert levels for selected or all manholes."),
                        Cmd("Sewer Settings", "CE_SEWSETTINGS ", "Configure styles, layers and label height."),
                        Cmd("Sewer Information", "CE_SEWINFO ", "Review links and generated output."),
                        Cmd("Sort Branch Labels", "CE_SEWLABELSORT ", "Stagger branch labels to reduce overlap."),
                        Cmd("Freeze Branch Labels", "CE_SEWLABELFREEZE ", "Freeze accepted label positions."),
                        Cmd("Unfreeze Branch Labels", "CE_SEWLABELUNFREEZE ", "Return labels to automatic sorting.")),
                    Menu(
                        "CE_TOOLS_WATER_PRODUCTION_MENU",
                        "Water Network\nProduction",
                        "Create water alignments, profiles and asset review markers.",
                        Cmd("Water Production Tools", "CE_WATERTOOLS ", "Open the complete water production menu."),
                        Cmd("Sequence Mains and Branches", "CE_WATERSEQ ", "Sequence water routes and branches."),
                        Cmd("Create / Refresh Alignments", "CE_WATERALIGN ", "Create linked water alignments."),
                        Cmd("Refresh Linked Alignments", "CE_WATERREFRESH ", "Refresh from current source geometry."),
                        Cmd("Create / Refresh Profiles", "CE_WATERPROFILE ", "Create EG profiles and profile views."),
                        Cmd("Place Valve and Hydrant Review Markers", "CE_WATERPLACE ", "Place linked valve and hydrant review markers."),
                        Cmd("Refresh Asset Review Markers", "CE_WATERPLACEREFRESH ", "Refresh asset locations from alignments."),
                        Cmd("Water Settings", "CE_WATERSETTINGS ", "Configure styles, layers and spacing."),
                        Cmd("Water Information", "CE_WATERINFO ", "Review links, output and settings.")),
                    Menu(
                        "CE_TOOLS_NETWORK_SCHEDULE_MENU",
                        "Network\nSchedules",
                        "Create linked asset schedules and reports for civil networks.",
                        Cmd("Network Schedule Tools", "CE_NETWORKSCHEDULETOOLS ", "Open create, refresh, export, information and BOQ workflows."),
                        Cmd("Create Network Schedule", "CE_NETWORKSCHEDULE ", "Create a linked asset schedule."),
                        Cmd("Refresh Network Schedule", "CE_NETWORKSCHEDULEREFRESH ", "Refresh linked asset values."),
                        Cmd("Export Network Schedule", "CE_NETWORKSCHEDULEEXPORT ", "Export the schedule to Excel."),
                        Cmd("Network Schedule Information", "CE_NETWORKSCHEDULEINFO ", "Review sources and link status."),
                        Cmd("Create BOQ from Schedule", "CE_NETWORKSCHEDULEBOQ ", "Hand schedule sources to the linked BOQ builder."),
                        Cmd("Network Summary Report", "CE_NETWORKREPORT2 ", "Show a network summary popup and optional table."),
                        Cmd("Selected Network Data", "CE_NETWORKPARTREPORT2 ", "Report selected pipe and structure data."))));
        }

        private static void AddStandardsPanel(RibbonTab tab)
        {
            AddPanel(
                tab,
                StandardsPanelId,
                "Standards & Details",
                Row(
                    Menu(
                        "CE_TOOLS_DESIGN_STANDARDS_MENU",
                        "Design\nStandards",
                        "Browse, search and apply the built-in design-standards reference library.",
                        Cmd("Design Standards Tools", "CE_DESIGNSTANDARDS ", "Open the design-standards library menu."),
                        Cmd("Browse Standards Library", "CE_STDBROWSE ", "Browse standards by engineering category."),
                        Cmd("Search Standards Library", "CE_STDSEARCH ", "Search by code, title, authority or keyword."),
                        Cmd("Apply Standard to Project", "CE_STDAPPLY ", "Record a catalogue item in project standards."),
                        Cmd("Current Project Standards", "CE_STANDARDINFO ", "Report current project standards.")),
                    Menu(
                        "CE_TOOLS_TYPICAL_DETAILS_MENU",
                        "Typical\nDetails",
                        "Configure, search and insert approved typical details.",
                        Cmd("Typical Details Tools", "CE_DETAILTOOLS ", "Open the typical-details workflow."),
                        Cmd("Set Master Library Folder", "CE_DETAILSETROOT ", "Store the project master-detail folder."),
                        Cmd("Search Detail Library", "CE_DETAILSEARCH ", "Search DWG, DXF and PDF assets."),
                        Cmd("Insert Approved Detail", "CE_DETAILINSERT ", "Insert an approved DWG detail as a block."),
                        Cmd("Typical Details Information", "CE_DETAILINFO ", "Review the library root and supported formats."),
                        Cmd("Dynamic Detail Tools", "CE_DETAILPARAMTOOLS ", "Open linked parametric detail workflows.")),
                    Menu(
                        "CE_TOOLS_ENGINEERING_ASSET_MENU",
                        "Engineering\nAssets",
                        "Search, insert and audit the preserved engineering asset catalogue.",
                        Cmd("Asset Library Tools", "CE_ASSETLIBTOOLS ", "Open asset search, insertion and audit workflows."),
                        Cmd("Search Asset Catalogue", "CE_ASSETSEARCH ", "Search the 33-asset catalogue."),
                        Cmd("Insert Engineering Asset", "CE_ASSETINSERT ", "Insert a selected approved asset."),
                        Cmd("Asset Information", "CE_ASSETINFO ", "Review catalogue and source information."),
                        Cmd("Asset Library Settings", "CE_ASSETLIBSETTINGS ", "Configure asset-library locations."),
                        Cmd("Audit Asset Catalogue", "CE_ASSETCATALOGAUDIT ", "Audit catalogue files and checksums."),
                        Cmd("Export Asset Template", "CE_ASSETCATALOGTEMPLATE ", "Create an asset catalogue template."),
                        Cmd("Check Asset Revisions", "CE_ASSETREVISIONCHECK ", "Review revision state for engineering assets."))));
        }

        private static void AddAnalysisPanel(RibbonTab tab)
        {
            AddPanel(
                tab,
                AnalysisPanelId,
                "Analysis",
                Row(
                    Menu(
                        "CE_TOOLS_QUANTITY_MENU",
                        "Quantity &\nBOQ Tools",
                        "Linked bills of quantities, explicit refresh and Excel exports by discipline.",
                        Cmd("BOQ Tools", "CE_BOQTOOLS ", "Open linked BOQ build, refresh, information and export workflows."),
                        Cmd("Build Linked BOQ", "CE_BOQBUILD ", "Create a linked drawing BOQ with quantity, rate and amount columns."),
                        Cmd("Refresh Linked BOQ", "CE_BOQREFRESH ", "Recalculate quantities from current linked source geometry while preserving matching rates."),
                        Cmd("Linked BOQ Information", "CE_BOQINFO ", "Review link schema, discipline, unit scale and stale source handles."),
                        Cmd("Export Linked BOQ to Excel", "CE_BOQEXPORT ", "Refresh and export a linked BOQ as a dependency-free .xlsx workbook."),
                        Cmd("Refresh All Linked Outputs", "CE_REFRESHALL ", "Refresh linked coordinate tables, setting-out schedules, parking labels, surface comparisons, BOQs, cost estimates and cross sections."),
                        Cmd("Linked Output Refresh Status", "CE_REFRESHSTATUS ", "Review linked-output counts, stale state and explicit-refresh status in the active drawing."),
                        Cmd("Out-of-Date Notifications", "CE_AUTOREFRESH ", "Turn bottom-right linked-output out-of-date notifications on or off. Linked outputs are never refreshed automatically."),
                        Cmd("Universal Dynamic Refresh", "CE_DYNAMICREFRESHALL ", "Refresh every linked CE table, leader, MText, COGO point, junction, sewer sequence and title block."),
                        Cmd("Universal Refresh Settings", "CE_DYNAMICREFRESHSETTINGS ", "Configure deferred automatic refresh after CE commands and source edits."),
                        Cmd("CE Click and Time Statistics", "CE_CLICKSTATS ", "Show command starts, every in-command click, right-click, undo/redo and elapsed time per DWG."),
                        Cmd("Road BOQ Excel", "CE_BOQROAD ", "Export road surfacing, layerworks, kerbs, drainage, markings and signs."),
                        Cmd("Platform BOQ Excel", "CE_BOQPLATFORM ", "Export platform, grading, layerworks and earthwork quantities."),
                        Cmd("Stormwater BOQ Excel", "CE_BOQSTORM ", "Export stormwater pipes, culverts, structures and open drainage."),
                        Cmd("Sewer BOQ Excel", "CE_BOQSEWER ", "Export sewer pipe and structure quantities."),
                        Cmd("Water BOQ Excel", "CE_BOQWATER ", "Export water pipe, valve, fitting and hydrant quantities."),
                        Cmd("Bulk-water BOQ Excel", "CE_BOQBULKWATER ", "Export bulk pipeline, storage, pump and fitting quantities."),
                        Cmd("Total Length", "CE_TLENGTH ", "Preserved quick total of selected curve lengths by layer."),
                        Cmd("Total Area", "CE_TAREA ", "Preserved quick total of selected areas by layer.")),
                    Menu(
                        "CE_TOOLS_WATER_SEWER_COST_MENU",
                        "Water & Sewer\nCost Estimate",
                        "Create and maintain the linked water/sewer Excel cost estimate while preserving workbook rates and formatting.",
                        Cmd("Cost Estimate Tools", "CE_WSCOSTTOOLS ", "Open create, refresh, information and automatic-refresh options."),
                        Cmd("Create Linked Cost Estimate", "CE_WSCOSTCREATE ", "Create a linked estimate from the installed or selected Excel template."),
                        Cmd("Refresh Cost Estimate", "CE_WSCOSTREFRESH ", "Update model-derived quantities without replacing workbook rates or formatting."),
                        Cmd("Cost Estimate Information", "CE_WSCOSTINFO ", "Review workbook path, link status, unit scale, asset counts and automatic-refresh state."),
                        Cmd("Automatic Cost Refresh", "CE_WSCOSTAUTO ", "Turn deferred refresh after drawing commands on or off."),
                        Cmd("Select Approved Cost Template", "CE_COSTTEMPLATESELECT ", "Select an XLSX/XLSM template such as the approved Annexure-A structure for future linked estimates."),
                        Cmd("Cost Template Information", "CE_COSTTEMPLATEINFO ", "Review the active cross-drawing cost-estimate template.")),
                    Menu(
                        "CE_TOOLS_DESIGN_REPORT_MENU",
                        "Design\nReports",
                        "Generate current project inventory reports, optional drawing tables and Excel exports.",
                        Cmd("Report & Production Tools", "CE_REPORTTOOLS ", "Open full, discipline, export, summary and drawing-book workflows."),
                        Cmd("Full Design Report", "CE_REPORTFULL ", "Generate a full model-space design report with CE link and layout status."),
                        Cmd("Choose Discipline Report", "CE_REPORTDISC ", "Generate General, Road, Platform, Stormwater, Sewer, Water or Bulk-water report."),
                        Cmd("Road Report", "CE_REPORTROAD ", "Generate the road-design inventory report."),
                        Cmd("Platform Report", "CE_REPORTPLATFORM ", "Generate the platform/grading design report."),
                        Cmd("Stormwater Report", "CE_REPORTSTORM ", "Generate the stormwater design report."),
                        Cmd("Sewer Report", "CE_REPORTSEWER ", "Generate the sewer design report."),
                        Cmd("Water Report", "CE_REPORTWATER ", "Generate the water design report."),
                        Cmd("Bulk-water Report", "CE_REPORTBULKWATER ", "Generate the bulk-water design report."),
                        Cmd("Export Design Report", "CE_REPORTEXPORT ", "Export a full or discipline design inventory as an .xlsx workbook.")),
                    Menu(
                        "CE_TOOLS_DYNAMIC_SECTION_MENU",
                        "Dynamic Cross\nSections",
                        "Create a linked cross section from a user-drawn line and keep it synchronised with monitored drawing changes.",
                        Cmd("Cross-section Tools", "CE_XSTOOLS ", "Open create, refresh, information, detach and monitor workflows."),
                        Cmd("Create Dynamic Cross Section", "CE_XSCREATE ", "Sample intersected surfaces and design objects and create a linked section view."),
                        Cmd("Refresh Dynamic Cross Section", "CE_XSREFRESH ", "Explicitly rebuild a linked section from current source geometry."),
                        Cmd("Cross-section Information", "CE_XSINFO ", "Review source, scales, samples, capture width and generated link status."),
                        Cmd("Detach Dynamic Cross Section", "CE_XSDETACH ", "Remove the link and keep or delete generated section geometry."),
                        Cmd("Dynamic-section Monitor", "CE_XSMONITOR ", "Report automatic update-manager and pending-refresh status."))));
        }

        private static void AddAdvancedPanel(RibbonTab tab)
        {
            AddPanel(
                tab,
                AdvancedPanelId,
                "Advanced Engineering",
                Row(
                    Menu(
                        "CE_TOOLS_HYDRAULIC_REVIEW_MENU",
                        "Hydrology &\nHydraulics",
                        "Catchment, flow, culvert, ponding and return-period review tools.",
                        Cmd("Hydraulic Tools", "CE_HYDRAULICTOOLS ", "Open rational-flow, catchment, culvert and pump review workflows."),
                        Cmd("Rational Flow", "CE_RATIONALFLOW ", "Calculate rational-method peak flow."),
                        Cmd("Quick Catchment Review", "CE_CATCHMENTQUICK ", "Review catchment area and runoff inputs."),
                        Cmd("Culvert Review", "CE_CULVERTREVIEW ", "Review preliminary culvert capacity."),
                        Cmd("Pump Review", "CE_PUMPREVIEW ", "Review pump duty information."),
                        Cmd("Surface Hydrology Tools", "CE_HYDROLOGYTOOLS ", "Open surface flow and catchment workflows."),
                        Cmd("Surface Flow Paths", "CE_SURFACEFLOW ", "Create surface flow-path review output."),
                        Cmd("Delineate Catchment", "CE_CATCHMENTDELINEATE ", "Delineate a surface catchment."),
                        Cmd("Compare Hydrographs", "CE_HYDROGRAPHCOMPARE ", "Compare pre/post hydrograph results."),
                        Cmd("Return-Period Hydrographs", "CE_HYDROGRAPHPERIODS ", "Generate return-period hydrograph reviews."),
                        Cmd("Flow Network and Culvert", "CE_FLOWNETWORK ", "Review a linked flow-network culvert system."),
                        Cmd("Surface Ponding Review", "CE_PONDINGREVIEW ", "Identify and report likely ponding areas."),
                        Cmd("Clear Hydraulic Review", "CE_HYDRAULICCLEAR ", "Clear generated hydraulic review output."),
                        Cmd("Clear Hydrology Review", "CE_HYDROLOGYCLEAR ", "Clear generated hydrology output.")),
                    Menu(
                        "CE_TOOLS_FLOOD_REVIEW_MENU",
                        "Flood Result\nReview",
                        "Review flood properties, frames and browser-based animations.",
                        Cmd("Flood Result Tools", "CE_FLOODRESULTTOOLS ", "Open flood result review workflows."),
                        Cmd("Flood Property Report", "CE_FLOODPROPERTYREPORT ", "Create a property-impact flood report."),
                        Cmd("Set Flood Frame", "CE_FLOODFRAMESET ", "Set plan/animation frame extents."),
                        Cmd("Reset Flood Frame", "CE_FLOODFRAMERESET ", "Clear stored flood frame extents."),
                        Cmd("Create Flood Animation", "CE_FLOODANIMATIONHTML ", "Generate an HTML flood-result animation.")),
                    Menu(
                        "CE_TOOLS_MODEL_EXCHANGE_MENU",
                        "Model & Xref\nExchange",
                        "Package, split, compare, back up and review project models and Xrefs.",
                        Cmd("Xref Project Tools", "CE_XREFPROJECTTOOLS ", "Open discipline split, backup and revision workflows."),
                        Cmd("Split Xrefs by Discipline", "CE_XREFDISCIPLINESPLIT ", "Build discipline-specific Xref sets."),
                        Cmd("Back Up All Xrefs", "CE_XREFBACKUPALL ", "Create a project Xref backup."),
                        Cmd("Xref Revision Dashboard", "CE_XREFREVISIONDASH ", "Review Xref revision differences."),
                        Cmd("Background Xref Tools", "CE_BACKGROUNDTOOLS ", "Open lightweight background workflows."),
                        Cmd("Split Background", "CE_XREFSPLIT ", "Split a selected background Xref."),
                        Cmd("Back Up Background", "CE_XREFBACKUP ", "Back up selected backgrounds."),
                        Cmd("Restore Background", "CE_XREFRESTORE ", "Restore a backed-up background."),
                        Cmd("Model Exchange Tools", "CE_MODELEXCHANGETOOLS ", "Open specialist model exchange workflows."),
                        Cmd("Export Model Package", "CE_MODELEXPORTPACKAGE ", "Create a specialist model package."),
                        Cmd("Import Model Results", "CE_MODELRESULTIMPORT ", "Import supported specialist results."),
                        Cmd("Model Result Information", "CE_MODELRESULTINFO ", "Review imported result links."),
                        Cmd("Model Design Audit", "CE_MODELREPORTTOOLS ", "Open model audit, export and information workflows."),
                        Cmd("Create Model Report", "CE_MODELREPORT ", "Create a model design audit report."),
                        Cmd("Export Model Report", "CE_MODELREPORTEXPORT ", "Export model audit results."),
                        Cmd("Fast Block Edit", "CE_BLOCKEDITFAST ", "Open a block or Xref definition for fast editing.")),
                    Menu(
                        "CE_TOOLS_ENGINEERING_SCHEDULE_MENU",
                        "Engineering\nSchedules",
                        "Linked road, sewer, section and standard quantity schedules.",
                        Cmd("Road Section Data Tools", "CE_ROADSECTIONDATATOOLS ", "Open road cross-section setting-out workflows."),
                        Cmd("Create Road Section Data", "CE_ROADSECTIONDATA ", "Create a linked road cross-section schedule."),
                        Cmd("Refresh Road Section Data", "CE_ROADSECTIONDATAREFRESH ", "Refresh road section values."),
                        Cmd("Export Road Section Data", "CE_ROADSECTIONDATAEXPORT ", "Export road section values."),
                        Cmd("Sewer Excavation Schedule", "CE_SEWEREXCAVATION ", "Create linked pipe/structure excavation, bedding, blanket-fill and backfill quantities."),
                        Cmd("Refresh Sewer Excavation", "CE_SEWEREXCAVATIONREFRESH ", "Refresh excavation quantities."),
                        Cmd("Export Sewer Excavation", "CE_SEWEREXCAVATIONEXPORT ", "Export detailed excavation quantities with a size-based Summary worksheet."),
                        Cmd("Standard Quantity Tools", "CE_STANDARDQTYTOOLS ", "Open standard quantity workflows."),
                        Cmd("Create Standard Quantity", "CE_STANDARDQTY ", "Create a linked office quantity template."),
                        Cmd("Refresh Standard Quantity", "CE_STANDARDQTYREFRESH ", "Refresh source quantities."),
                        Cmd("Export Standard Quantity", "CE_STANDARDQTYEXPORT ", "Export a standard quantity schedule."),
                        Cmd("Detailed Section Tools", "CE_SECTIONDETAILTOOLS ", "Open linked section-detail annotation workflows."),
                        Cmd("Create Detailed Section", "CE_SECTIONDETAILCREATE ", "Create a linked detailed-section annotation."),
                        Cmd("Refresh Detailed Section", "CE_SECTIONDETAILREFRESH ", "Refresh linked detailed-section output.")),
                    Menu(
                        "CE_TOOLS_REVIEW_PRESENTATION_MENU",
                        "Review &\nPresentation",
                        "Grading diagnostics, survey comparison, pump systems and project presentation.",
                        Cmd("Grading Diagnostics", "CE_GRADINGDIAGNOSTICS ", "Open low-point and low-slope review workflows."),
                        Cmd("Find Low Points", "CE_LOWPOINTS ", "Identify grading low points."),
                        Cmd("Find Low Slopes", "CE_LOWSLOPE ", "Identify areas below the selected slope."),
                        Cmd("Clear Grading Review", "CE_GRADINGREVIEWCLEAR ", "Clear generated grading review output."),
                        Cmd("Survey Comparison Tools", "CE_SURVEYCOMPARETOOLS ", "Compare original and corrected survey surfaces."),
                        Cmd("Survey Changes", "CE_SURVEYCHANGES ", "Create a read-only survey change report."),
                        Cmd("Export Survey Changes", "CE_SURVEYCHANGEEXPORT ", "Export survey comparison results."),
                        Cmd("Pump System Tools", "CE_PUMPSYSTEMTOOLS ", "Open pump-system review workflows."),
                        Cmd("Pump System Review", "CE_PUMPSYSTEMREVIEW ", "Review a pump system and duty points."),
                        Cmd("Pump Folder Review", "CE_PUMPFOLDERREVIEW ", "Review pump files in a selected folder."),
                        Cmd("Pump Curve Template", "CE_PUMPCURVETEMPLATE ", "Create a pump-curve input template."),
                        Cmd("Project Presentation Tools", "CE_PROJECTPRESENTATIONTOOLS ", "Open project presentation workflows."),
                        Cmd("Create Project Presentation", "CE_PRESENTATIONCREATE ", "Create a presentation package."),
                        Cmd("Preview Project Presentation", "CE_PRESENTATIONPREVIEW ", "Preview generated presentation content."),
                        Cmd("Ribbon Icon Settings", "CE_RIBBONICONS ", "Review or configure CE Tools ribbon icon mode."))));
        }

        private static void AddProductionPanel(RibbonTab tab)
        {
            AddPanel(
                tab,
                ProductionPanelId,
                "Production",
                Row(
                    Menu(
                        "CE_TOOLS_CLIENT_BOOK_MENU",
                        "Project Closeout\nClient Book",
                        "Create linked A4/A3 client summary books at project closeout.",
                        Cmd("Project Closeout - A4 and A3", "CE_PROJECTCLOSEOUT ", "Create or refresh the complete A4 and A3 client summary books."),
                        Cmd("Create Client Book", "CE_CLIENTBOOK ", "Choose A4, A3 or both and create linked summary pages."),
                        Cmd("Refresh Client Book", "CE_CLIENTBOOKREFRESH ", "Refresh all linked client-book pages from current project information."),
                        Cmd("Client Book Information", "CE_CLIENTBOOKINFO ", "Review page links, issue stage, revision and stale generated handles."),
                        Cmd("Export Client Book Index", "CE_CLIENTBOOKINDEX ", "Export the linked client-book register to Excel.")),
                    Menu(
                        "CE_TOOLS_PRODUCTION_MENU",
                        "Summary &\nDrawing Books",
                        "Generate project summary sheets and A-series client/construction drawing-book layouts.",
                        Cmd("Finish Runtime Comments", "CE_RUNTIMEFINISH ", "Open the final annotation, sewer-label and profile-band completion centre before building."),
                        Cmd("Apply Sewer Label Presentation", "CE_PIPELABELPRESENTATION ", "Apply selected pipe/structure label styles, flow arrows, plan readability and bounded offsets."),
                        Cmd("Import Road Band Set + Native Bands", "CE_ROADBANDLABELS ", "Open the Bands-tab batch window, apply a band set and labels to multiple profile views, then inspect the native Civil 3D dialog."),
                        Cmd("Batch Profile View Band Sets", "CE_PROFILEBANDSBATCH ", "Apply and link multiple band sets across selected profile views."),
                        Cmd("Refresh Profile View Bands", "CE_PROFILEBANDREFRESH ", "Refresh live profile/network band data at structures and manholes."),
                        Cmd("Apply Civil 3D Rules - Sewer Parts", "CE_SEWERAPPLYRULESMULTI ", "Apply a selected surface and Civil 3D pipe/structure rule sets to multiple selected sewer parts."),
                        Cmd("Sewer Profile Label Styles - Multiple Views", "CE_SEWPROFILELABELSTYLESMULTI ", "Apply pipe and structure profile label styles to multiple selected profile views without changing slopes or cover rules."),
                        Cmd("Draw Sewer Networks - Multiple Profile Views", "CE_SEWPROFILEPARTSMULTI ", "Choose multiple gravity networks and draw their pipes and structures in selected profile views."),
                        Cmd("Draw Selected Sewer Parts - Matching Profile Views", "CE_SEWSELECTEDPARTSPROFILEMULTI ", "Select multiple sewer parts and profile views; place parts in views matching the network or alignment geometry."),
                        Cmd("Production Tools", "CE_REPORTTOOLS ", "Open reports, summaries and drawing-book workflows."),
                        Cmd("Create Project Summary Sheet", "CE_SUMMARYSHEET ", "Create a linked project metadata, discipline and production-readiness summary."),
                        Cmd("Refresh Project Summary", "CE_SUMMARYREFRESH ", "Refresh the summary from current model, links and layouts."),
                        Cmd("Summary Link Information", "CE_SUMMARYINFO ", "Review summary anchor and generated-object link status."),
                        Cmd("Create A-Series Drawing Books", "CE_DRAWINGBOOK ", "Create or refresh A4/A3 client and A1/A0 construction layouts."),
                        Cmd("Export Drawing Book Index", "CE_BOOKINDEX ", "Export the standard and existing layout register to Excel."))));
        }

        private static RibbonItem[] Row(params RibbonItem[] items)
        {
            return items;
        }

        private static void AddPanel(
            RibbonTab tab,
            string panelId,
            string title,
            params RibbonItem[][] rows)
        {
            var source = new RibbonPanelSource
            {
                Id = panelId,
                Title = CeCommandDisplayNames.Normalize(title).ToUpperInvariant()
            };
            foreach (RibbonItem[] row in rows)
            {
                foreach (RibbonItem item in row)
                    source.Items.Add(item);
            }
            tab.Panels.Add(new RibbonPanel { Source = source });
        }

        private static RibbonMenuButton Menu(
            string id,
            string text,
            string toolTip,
            params RibbonCommandDefinition[] commands)
        {
            var menu = new RibbonMenuButton
            {
                Id = id,
                Text = CeCommandDisplayNames.Normalize(text),
                ShowText = true,
                ShowImage = true,
                Size = RibbonItemSize.Large,
                Image = RibbonVisuals.Small(id),
                LargeImage = RibbonVisuals.Large(id),
                ToolTip = toolTip
            };
            int commandIndex = 0;
            foreach (RibbonCommandDefinition command in commands)
                menu.Items.Add(CreateCommandButton(command, id, commandIndex++));
            return menu;
        }

        private static RibbonCommandDefinition Cmd(
            string text,
            string command,
            string toolTip)
        {
            return new RibbonCommandDefinition(
                NormalizeDisplayText(text),
                command,
                toolTip);
        }

        private static string NormalizeDisplayText(string text)
        {
            string value = CeCommandDisplayNames.Normalize(text);
            return string.IsNullOrWhiteSpace(value) ? "CE-Command" : value;
        }

        private static RibbonMenuItem CreateCommandButton(
            RibbonCommandDefinition definition,
            string menuId,
            int commandIndex)
        {
            return new RibbonMenuItem
            {
                Id = (menuId ?? "CE_TOOLS_MENU") + "_COMMAND_" +
                    commandIndex.ToString(System.Globalization.CultureInfo.InvariantCulture) +
                    "_" + definition.Command.Trim().Replace(' ', '_'),
                Text = CeCommandDisplayNames.Normalize(definition.Text),
                ShowText = true,
                ShowImage = true,
                Image = RibbonVisuals.CommandSmall(definition.Command),
                CommandParameter = definition.Command,
                CommandHandler = new RibbonCommandHandler(),
                ToolTip = definition.ToolTip
            };
        }

        private sealed class RibbonCommandDefinition
        {
            public RibbonCommandDefinition(string text, string command, string toolTip)
            {
                Text = text;
                Command = command;
                ToolTip = toolTip;
            }

            public string Text { get; }
            public string Command { get; }
            public string ToolTip { get; }
        }
    }

    internal sealed class RibbonCommandHandler : ICommand
    {
#pragma warning disable 67
        public event EventHandler CanExecuteChanged;
#pragma warning restore 67

        public bool CanExecute(object parameter)
        {
            return AcApplication.DocumentManager.MdiActiveDocument != null;
        }

        public void Execute(object parameter)
        {
            string command = parameter as string;
            var button = parameter as RibbonButton;
            var menuItem = parameter as RibbonMenuItem;
            if (string.IsNullOrWhiteSpace(command) && button != null)
                command = button.CommandParameter as string;
            if (string.IsNullOrWhiteSpace(command) && menuItem != null)
                command = menuItem.CommandParameter as string;
            if (string.IsNullOrWhiteSpace(command)) return;

            AcApplication.DocumentManager.MdiActiveDocument?.SendStringToExecute(
                command.Trim() + " ",
                true,
                false,
                true);
        }
    }
}
