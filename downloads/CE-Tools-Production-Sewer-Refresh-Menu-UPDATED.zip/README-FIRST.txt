11 NOVEMBER 2026 - ALIGNMENT-BASED MINIMUM SEWER INTERVALS

Added CE_SEWERSTRUCTUREINTERVALUPDATE with network/interval popup and preview.
Uses branch alignment distances: 242.88 m / minimum 60 m = four 60.72 m intervals.
Fixed ends, vertices, junctions and design transitions remain. Compatible ordinary
intermediate structures can be replaced. Includes preservation checks, renumbering,
source-style labels and existing profile/section view membership.
FINAL SEWER PRODUCTION retains the requested first six steps and now includes
Existing Network Maintenance. All earlier source update payloads are retained.
Read SEWER-STRUCTURE-INTERVAL-UPDATE.md for supported cases and runtime checks.
This is a SOURCE UPDATE KIT. It must be applied to the full repo and rebuilt.

10 NOVEMBER 2026 - ORTHOGONAL NETWORK ADDITION

Added OrthogonalPolylineNetworkCommands.cs from your complete-source upload.
Replaced September05FieldGeometryCommandFrontDoor.cs to register
CE_CREATEORTHOGONALNETWORK and retain the existing popup/fillet/grid commands.
The new command creates missing orthogonal connector geometry while preserving
selected source lines/polylines. Both supplied files are in COMMAND-UPDATES/.
Run APPLY-CE-TOOLS-UPDATE.py against the full source repository, then rebuild.
Earlier erf-boundary, sewer-layout and refresh updates remain included.
Source checks do not replace a native Civil 3D compile and drawing test.

10 NOVEMBER 2026 COMMAND UPDATE

Added CeErfGroupBoundaryCommands.cs:
- CE_CREATEERFGROUPBOUNDARIES
- CE_CHECKERFGEOMETRY

Replaced August20GeometryFirstSewerCommands.cs with the supplied
CE_SEWERLAYOUTROADRESERVE_Complete_Source.cs (canonical filename used).
This complete class also contains the related midblock, centreline, network,
refresh and legacy-bridge commands. Do not compile both filenames together.

The APPLY updater now installs both files from COMMAND-UPDATES/, backs up
existing targets and rejects duplicate command/class owners before writing.
The existing sewer-network and refresh-menu patches below are retained.
These new commands are included in this ZIP; no GitHub commit is implied.
Run the updater against your latest full source checkout, then rebuild.
Native Civil 3D compilation and drawing tests remain required.

--- Previous kit details (9 November 2026) ---
CE TOOLS — SEWER + LINKED REFRESH CONTEXT MENU CORRECTION
9 November 2026

WHAT THIS ZIP IS
- A safe SOURCE-CODE UPDATE KIT for your existing FULL CE Tools repository.
- It is NOT a compiled DLL, standalone application, or installer.
- Do NOT overwrite a whole GitHub main checkout with older ribbon-source files.
- The 11 source files from your uploaded ZIP are retained separately under
  REFERENCE-ONLY/, because some of them are older than current GitHub main.

CHANGES IN THIS KIT
1. CE_SEWERNETWORKMULTI reuses the established surface-first network engine,
   including reference surface, pipe/structure rule sets, connected junctions
   and user-configurable structure spacing (default 80 drawing units).
2. Hide the old 'Linked CE output may be stale. Refresh?' popup by default,
   including previously saved notification preferences. Existing stale-state
   tracking and manual refresh behaviour are preserved.
3. In the CE Tools right-click submenu add:
   - Refresh Linked CE Outputs       (CE_REFRESHALL)
   - Ignore / Dismiss Linked Reminder (CE_REFRESHDISMISS)
   - Linked Output Refresh Status   (CE_REFRESHSTATUS)
   - Out-of-Date Notice On / Off    (CE_AUTOREFRESH) [optional]
4. Remove the notice-settings shortcut from the main CE TOOLS ribbon;
   retain all other production and utility commands.
5. Back up every changed file and update the source validator to reflect the
   new menu location.

TO APPLY ON WINDOWS (TO A COMPLETE REPOSITORY)
A. Download and extract the CURRENT, FULL CE-tools repository from:
   https://github.com/zjondreangermund/CE-tools
   (Use Code > Download ZIP, or use your existing FULL local repository.)
B. Back up your local source directory.
C. Extract THIS update kit and run in PowerShell or Command Prompt:
   py -3 APPLY-CE-TOOLS-UPDATE.py "C:\path\to\CE-tools-main" --dry-run
   py -3 APPLY-CE-TOOLS-UPDATE.py "C:\path\to\CE-tools-main"
   If Python is installed as python instead of py, use python.
D. Source validators run automatically; if any fails, do not install.
E. Run the existing Build-Install-Civil3D2024-Safe.ps1 (or the version-matched
   2023 script) from your COMPLETE repo. Restart Civil 3D to load the new DLL.
F. In a COPY of your DWG, check CE_SEWERNETWORKMULTI and the new CE Tools
   right-click Refresh/Ignore actions. Check that no popup appears until you
   explicitly opt into out-of-date notices again.

ALREADY USING LATEST GITHUB MAIN?
The original refresh changes were committed to main. The new 10 November
command payloads must still be applied from this ZIP before rebuilding.

VERIFICATION AND LIMITATION
- GitHub core tests: passed (commit ed741f0, 9 Nov 2026).
- GitHub source package validation: passed.
- Native Windows Civil 3D build: NOT run by GitHub (job skipped).
- Runtime in your particular 2023/2024 Civil 3D installation: NOT verified.
- Code from REFERENCE-ONLY is supplied solely to preserve the contents of your
  upload; never copy it indiscriminately over newer repository files.
