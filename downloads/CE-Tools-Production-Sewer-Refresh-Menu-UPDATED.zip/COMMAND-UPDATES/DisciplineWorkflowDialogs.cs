using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using Autodesk.AutoCAD.ApplicationServices;
using Autodesk.AutoCAD.DatabaseServices;
using AcApplication = Autodesk.AutoCAD.ApplicationServices.Core.Application;

namespace CETools.Civil3D
{
    /// <summary>
    /// Shared WPF presentation for production workflow selection and persisted
    /// discipline settings. Drawing picks remain native Civil 3D interactions;
    /// configuration and command selection are handled by normal windows.
    /// </summary>
    internal static class DisciplineWorkflowDialogs
    {
        private static readonly Dictionary<string, string> LastWorkflowCommands =
            new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        public static string SelectWorkflow(
            string title,
            string note,
            IList<DisciplineWorkflowAction> actions)
        {
            var window = new DisciplineWorkflowWindow(
                title,
                note,
                actions,
                LastWorkflowCommand(title));
            AcApplication.ShowModalWindow(window);
            return window.SelectedCommand ?? string.Empty;
        }

        public static void SelectAndRun(
            Document document,
            string title,
            string note,
            IList<DisciplineWorkflowAction> actions)
        {
            if (document == null) return;
            var window = new DisciplineWorkflowWindow(
                title,
                note,
                actions,
                LastWorkflowCommand(title))
            {
                KeepOpenOnAction = true
            };
            // Restore focus to Civil 3D when a modeless production centre closes.
            // No minimization or WindowState change is performed on AutoCAD.
            window.Closed += delegate
            {
                try
                {
                    Document active = AcApplication.DocumentManager.MdiActiveDocument;
                    if (active != null && active.Window != null)
                    {
                        var focus = active.Window.GetType().GetMethod("Focus", Type.EmptyTypes);
                        if (focus != null) focus.Invoke(active.Window, null);
                    }
                }
                catch { }
            };
            AcApplication.ShowModelessWindow(window);
        }

        internal static void RememberWorkflowCommand(
            string title,
            string command)
        {
            if (string.IsNullOrWhiteSpace(title) ||
                string.IsNullOrWhiteSpace(command))
                return;
            LastWorkflowCommands[title.Trim()] =
                command.Trim();
        }

        private static string LastWorkflowCommand(
            string title)
        {
            if (string.IsNullOrWhiteSpace(title))
                return string.Empty;
            string command;
            return LastWorkflowCommands.TryGetValue(
                       title.Trim(),
                       out command)
                ? command
                : string.Empty;
        }

        public static bool EditSettings(ProductionSettingsDialogModel model)
        {
            if (model == null) return false;
            Document document = AcApplication.DocumentManager.MdiActiveDocument;
            // User-local defaults are loaded first so Road/Sewer/SW/Water/Bulk
            // Water settings remain available when another DWG is opened.
            // Start from the DWG settings, then load the last confirmed user
            // choices LAST so a stale per-drawing record cannot silently reset
            // the user's most recently saved popup values.
            if (document != null && !CrossDrawingSettingsPreference.UseSavedProjectSettings)
                ProductionSettingsPersistenceStore.Load(document.Database, model);
            CrossDrawingProductionSettingsStore.Load(model);
            model.PreferSuppliedDefaults = CrossDrawingSettingsPreference.UseSavedProjectSettings;
            var window = new ProductionSettingsWindow(model);
            AcApplication.ShowModalWindow(window);
            if (window.Accepted)
            {
                if (document != null)
                    ProductionSettingsPersistenceStore.Save(document.Database, model);
                CrossDrawingProductionSettingsStore.Save(model);
            }
            return window.Accepted;
        }

        public static bool Confirm(string title, string message)
        {
            return CeMessageDialog.Show(title, message, true);
        }
    }

    internal sealed class DisciplineWorkflowAction
    {
        public DisciplineWorkflowAction(
            string title,
            string command,
            string description,
            string group)
        {
            Title = title ?? string.Empty;
            Command = command ?? string.Empty;
            Description = description ?? string.Empty;
            Group = group ?? string.Empty;
        }

        public string Title { get; private set; }
        public string Command { get; private set; }
        public string Description { get; private set; }
        public string Group { get; private set; }
    }

    internal sealed class DisciplineWorkflowWindow : Window
    {
        public DisciplineWorkflowWindow(
            string title,
            string note,
            IList<DisciplineWorkflowAction> actions,
            string initiallySelectedCommand = "")
        {
            Title = title ?? "CE Tools Workflow";
            Button initialButton = null;
            Width = 760;
            Height = 620;
            MinWidth = 600;
            MinHeight = 420;
            WindowStartupLocation = WindowStartupLocation.CenterScreen;
            ResizeMode = ResizeMode.CanResizeWithGrip;
            ShowInTaskbar = false;
            Background = new SolidColorBrush(Color.FromRgb(244, 247, 249));

            var root = new Grid { Margin = new Thickness(18) };
            root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            root.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
            root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });

            var heading = new TextBlock
            {
                Text = title ?? "CE Tools Workflow",
                FontSize = 20,
                FontWeight = FontWeights.SemiBold,
                Foreground = new SolidColorBrush(Color.FromRgb(24, 52, 74)),
                Margin = new Thickness(0, 0, 0, 5)
            };
            root.Children.Add(heading);

            var noteBlock = new TextBlock
            {
                Text = note ?? string.Empty,
                TextWrapping = TextWrapping.Wrap,
                Foreground = Brushes.DimGray,
                Margin = new Thickness(0, 0, 0, 14)
            };
            Grid.SetRow(noteBlock, 1);
            root.Children.Add(noteBlock);

            var stack = new StackPanel();
            foreach (IGrouping<string, DisciplineWorkflowAction> group in
                (actions ?? new List<DisciplineWorkflowAction>())
                    .GroupBy(item => item.Group)
                    .OrderBy(item => item.Key))
            {
                stack.Children.Add(new TextBlock
                {
                    Text = group.Key,
                    FontSize = 13,
                    FontWeight = FontWeights.SemiBold,
                    Foreground = new SolidColorBrush(Color.FromRgb(40, 113, 151)),
                    Margin = new Thickness(0, 8, 0, 7)
                });
                foreach (DisciplineWorkflowAction action in group)
                {
                    var button = new Button
                    {
                        Tag = action,
                        HorizontalContentAlignment = HorizontalAlignment.Stretch,
                        Padding = new Thickness(14, 11, 14, 11),
                        Margin = new Thickness(0, 0, 0, 7),
                        Content = BuildActionContent(action),
                        ToolTip = BuildActionToolTip(action)
                    };
                    button.Click += OnActionClick;
                    if (!string.IsNullOrWhiteSpace(initiallySelectedCommand) &&
                        string.Equals(
                            action.Command,
                            initiallySelectedCommand,
                            StringComparison.OrdinalIgnoreCase))
                    {
                        initialButton = button;
                        button.IsDefault = true;
                    }
                    stack.Children.Add(button);
                }
            }

            var scroll = new ScrollViewer
            {
                Content = stack,
                VerticalScrollBarVisibility = ScrollBarVisibility.Auto
            };
            Grid.SetRow(scroll, 2);
            root.Children.Add(scroll);

            var close = new Button
            {
                Content = "Close",
                IsCancel = true,
                MinWidth = 100,
                Padding = new Thickness(14, 7, 14, 7),
                Margin = new Thickness(0, 12, 0, 0),
                HorizontalAlignment = HorizontalAlignment.Right
            };
            Grid.SetRow(close, 3);
            root.Children.Add(close);
            Content = root;

            if (initialButton != null)
            {
                Loaded += delegate
                {
                    try
                    {
                        initialButton.Focus();
                        initialButton.BringIntoView();
                    }
                    catch { }
                };
            }
        }

        public string SelectedCommand { get; private set; }
        public bool KeepOpenOnAction { get; set; }

        private static UIElement BuildActionContent(DisciplineWorkflowAction action)
        {
            var grid = new Grid
            {
                HorizontalAlignment = HorizontalAlignment.Stretch
            };
            grid.ColumnDefinitions.Add(new ColumnDefinition
            {
                Width = new GridLength(330),
                MinWidth = 300
            });
            grid.ColumnDefinitions.Add(new ColumnDefinition
            {
                Width = new GridLength(28)
            });
            grid.ColumnDefinitions.Add(new ColumnDefinition
            {
                Width = new GridLength(1, GridUnitType.Star),
                MinWidth = 220
            });

            var title = new StackPanel
            {
                Margin = new Thickness(0, 1, 0, 1),
                VerticalAlignment = VerticalAlignment.Center
            };
            title.Children.Add(new TextBlock
            {
                Text = action.Title,
                FontWeight = FontWeights.SemiBold,
                FontSize = 12.5,
                TextWrapping = TextWrapping.Wrap,
                Margin = new Thickness(0, 0, 0, 3)
            });
            title.Children.Add(new TextBlock
            {
                Text = action.Command,
                FontFamily = new FontFamily("Consolas"),
                Foreground = Brushes.DimGray,
                TextWrapping = TextWrapping.Wrap,
                FontSize = 10.5
            });
            Grid.SetColumn(title, 0);
            grid.Children.Add(title);

            UIElement description;
            string details = action.Description ?? string.Empty;
            if (details.Length > 90)
            {
                var expander = new Expander
                {
                    Header = details.Length > 72
                        ? details.Substring(0, 69) + "..."
                        : details,
                    IsExpanded = false,
                    FontSize = 10.5,
                    FontWeight = FontWeights.Normal,
                    Foreground = Brushes.DimGray,
                    VerticalAlignment = VerticalAlignment.Center,
                    Content = new TextBlock
                    {
                        Text = details,
                        TextWrapping = TextWrapping.Wrap,
                        FontSize = 10.5,
                        FontWeight = FontWeights.Normal,
                        Foreground = Brushes.DimGray,
                        LineHeight = 15,
                        Margin = new Thickness(0, 4, 0, 0)
                    }
                };
                description = expander;
            }
            else
            {
                description = new TextBlock
                {
                    Text = details,
                    TextWrapping = TextWrapping.Wrap,
                    VerticalAlignment = VerticalAlignment.Center,
                    Foreground = Brushes.DimGray,
                    FontSize = 10.5,
                    LineHeight = 15
                };
            }
            Grid.SetColumn(description, 2);
            grid.Children.Add(description);
            return grid;
        }

        private static ToolTip BuildActionToolTip(DisciplineWorkflowAction action)
        {
            var panel = new StackPanel { MaxWidth = 455, Margin = new Thickness(9) };
            panel.Children.Add(new TextBlock { Text = action.Title, FontWeight = FontWeights.SemiBold,
                Foreground = Brushes.White, TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 0, 0, 7) });
            panel.Children.Add(new TextBlock { Text = action.Description, Foreground = Brushes.White,
                TextWrapping = TextWrapping.Wrap, Margin = new Thickness(0, 0, 0, 9) });
            panel.Children.Add(new TextBlock { Text = "Command: " + action.Command,
                Foreground = Brushes.White, FontFamily = new FontFamily("Consolas"), TextWrapping = TextWrapping.Wrap });
            return new ToolTip { Content = panel, Background = new SolidColorBrush(Color.FromRgb(17, 23, 34)),
                Foreground = Brushes.White, BorderBrush = new SolidColorBrush(Color.FromRgb(78, 95, 120)),
                BorderThickness = new Thickness(1), Padding = new Thickness(6) };
        }

        private void OnActionClick(object sender, RoutedEventArgs args)
        {
            var button = sender as Button;
            var action = button == null ? null : button.Tag as DisciplineWorkflowAction;
            if (action == null || string.IsNullOrWhiteSpace(action.Command)) return;
            SelectedCommand = action.Command;
            DisciplineWorkflowDialogs.RememberWorkflowCommand(
                Title,
                action.Command);

            if (KeepOpenOnAction)
            {
                string queuedCommand = action.Command.Trim() + " ";
                string discipline = ResolveStyleDiscipline(Title);

                Dispatcher.BeginInvoke(new Action(delegate
                {
                    Document document = null;
                    try
                    {
                        document = AcApplication.DocumentManager.MdiActiveDocument;
                        if (document == null) return;

                        if (!string.IsNullOrWhiteSpace(discipline))
                        {
                            try
                            {
                                using (DocumentLock documentLock = document.LockDocument())
                                {
                                    August11DisciplineStylePresetManager.ActivateForProduction(
                                        document.Database,
                                        discipline);
                                }
                            }
                            catch (System.Exception presetException)
                            {
                                try
                                {
                                    document.Editor.WriteMessage(
                                        "\nCE Tools: {0} style preset could not be pre-activated; the command will still run. {1}",
                                        discipline,
                                        presetException.Message);
                                }
                                catch { }
                            }
                        }

                        document.SendStringToExecute(
                            queuedCommand,
                            true,
                            false,
                            true);
                    }
                    catch (System.Exception dispatchException)
                    {
                        try
                        {
                            if (document != null)
                                document.Editor.WriteMessage(
                                    "\nCE Tools production command could not be queued safely. {0}",
                                    dispatchException.Message);
                        }
                        catch { }
                    }
                }));
                return;
            }

            DialogResult = true;
            Close();
        }

        private static string ResolveStyleDiscipline(string title)
        {
            string value = (title ?? string.Empty).ToUpperInvariant();
            if (value.Contains("BULK WATER")) return "Bulk Water";
            if (value.Contains("STORMWATER")) return "Stormwater";
            if (value.Contains("SEWER")) return "Sewer";
            if (value.Contains("PLATFORM")) return "Platforms";
            if (value.Contains("PARKING")) return "Parking";
            if (value.Contains("FLOOD")) return "Flood";
            if (value.Contains("SURVEY")) return "Survey";
            if (value.Contains("ROAD")) return "Roads";
            if (value.Contains("WATER")) return "Water";
            return string.Empty;
        }
    }

    internal enum ProductionSettingsFieldKind
    {
        Text,
        PositiveDouble,
        PositiveInteger,
        PaperHeight,
        Choice
    }

    internal sealed class ProductionSettingsField
    {
        public ProductionSettingsField(
            string key,
            string group,
            string label,
            string description,
            ProductionSettingsFieldKind kind,
            string value,
            IEnumerable<string> choices = null)
        {
            Key = key ?? string.Empty;
            Group = group ?? string.Empty;
            Label = label ?? string.Empty;
            Description = description ?? string.Empty;
            Kind = kind;
            Value = value ?? string.Empty;
            Choices = (choices ?? new string[0])
                .Where(item => !string.IsNullOrWhiteSpace(item))
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .OrderBy(item => item, StringComparer.OrdinalIgnoreCase)
                .ToList();
        }

        public string Key { get; private set; }
        public string Group { get; private set; }
        public string Label { get; private set; }
        public string Description { get; private set; }
        public ProductionSettingsFieldKind Kind { get; private set; }
        public string Value { get; set; }
        public IList<string> Choices { get; private set; }
    }

    internal sealed class ProductionSettingsDialogModel
    {
        private readonly List<ProductionSettingsField> _fields =
            new List<ProductionSettingsField>();
        internal readonly Dictionary<string, Func<string, IDictionary<string, string>>> ChoiceChanges =
            new Dictionary<string, Func<string, IDictionary<string, string>>>(StringComparer.OrdinalIgnoreCase);

        public void OnChoiceChanged(string fieldKey, Func<string, IDictionary<string, string>> values)
        {
            if (string.IsNullOrWhiteSpace(fieldKey) || values == null) return;
            ChoiceChanges[fieldKey] = values;
        }

        public ProductionSettingsDialogModel(string title, string note)
        {
            Title = title ?? "CE Tools Settings";
            Note = note ?? string.Empty;
        }

        public string Title { get; private set; }
        public string Note { get; private set; }
        internal bool PreferSuppliedDefaults { get; set; }
        public IList<ProductionSettingsField> Fields { get { return _fields; } }

        public void AddText(string key, string group, string label, string value, string description)
        {
            Add(key, group, label, value, description, ProductionSettingsFieldKind.Text);
        }

        public void AddChoice(
            string key,
            string group,
            string label,
            string value,
            string description,
            IEnumerable<string> choices)
        {
            _fields.Add(new ProductionSettingsField(
                key,
                group,
                label,
                description,
                ProductionSettingsFieldKind.Choice,
                value,
                choices));
        }

        public void AddPositiveDouble(string key, string group, string label, double value, string description)
        {
            Add(key, group, label, value.ToString("0.###", CultureInfo.InvariantCulture), description, ProductionSettingsFieldKind.PositiveDouble);
        }

        public void AddPositiveInteger(string key, string group, string label, int value, string description)
        {
            Add(key, group, label, value.ToString(CultureInfo.InvariantCulture), description, ProductionSettingsFieldKind.PositiveInteger);
        }

        public void AddPaperHeight(string key, string group, string label, double value, string description)
        {
            // Always show an explicit absolute paper-mm value (2.0 rather than
            // 2) so the settings window matches the Civil 3D Properties value.
            double normalized = PaperAnnotationScale.NormalizeConfiguredPaperHeight(value);
            Add(key, group, label, normalized.ToString("0.0##", CultureInfo.InvariantCulture), description, ProductionSettingsFieldKind.PaperHeight);
        }

        public string Text(string key)
        {
            ProductionSettingsField field = Find(key);
            return field == null ? string.Empty : (field.Value ?? string.Empty).Trim();
        }

        public double Double(string key, double fallback)
        {
            double value;
            return TryDouble(Text(key), out value) && value > 0.0 ? value : fallback;
        }

        public int Integer(string key, int fallback)
        {
            int value;
            return int.TryParse(Text(key), NumberStyles.Integer, CultureInfo.InvariantCulture, out value) && value > 0
                ? value
                : fallback;
        }

        private void Add(
            string key,
            string group,
            string label,
            string value,
            string description,
            ProductionSettingsFieldKind kind)
        {
            _fields.Add(new ProductionSettingsField(key, group, label, description, kind, value));
        }

        private ProductionSettingsField Find(string key)
        {
            return _fields.FirstOrDefault(item => string.Equals(item.Key, key, StringComparison.OrdinalIgnoreCase));
        }

        internal static bool TryDouble(string text, out double value)
        {
            return double.TryParse(text, NumberStyles.Float, CultureInfo.InvariantCulture, out value) ||
                   double.TryParse(text, NumberStyles.Float, CultureInfo.CurrentCulture, out value);
        }
    }

    internal sealed class ProductionSettingsWindow : Window
    {
        private readonly ProductionSettingsDialogModel _model;
        private readonly ProductionSettingsDialogModel _rememberedDefaults;
        private readonly Dictionary<ProductionSettingsField, Control> _controls =
            new Dictionary<ProductionSettingsField, Control>();

        public ProductionSettingsWindow(ProductionSettingsDialogModel model)
        {
            _model = model;
            _rememberedDefaults = PopupLastUsedDefaults.Load(model, AcApplication.DocumentManager.MdiActiveDocument, model.PreferSuppliedDefaults);
            Title = model.Title;
            Width = 820;
            Height = 680;
            MinWidth = 660;
            MinHeight = 480;
            WindowStartupLocation = WindowStartupLocation.CenterScreen;
            ResizeMode = ResizeMode.CanResizeWithGrip;
            ShowInTaskbar = false;
            Background = new SolidColorBrush(Color.FromRgb(244, 247, 249));

            var root = new Grid { Margin = new Thickness(18) };
            root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });
            root.RowDefinitions.Add(new RowDefinition { Height = new GridLength(1, GridUnitType.Star) });
            root.RowDefinitions.Add(new RowDefinition { Height = GridLength.Auto });

            var heading = new TextBlock
            {
                Text = model.Title,
                FontSize = 20,
                FontWeight = FontWeights.SemiBold,
                Foreground = new SolidColorBrush(Color.FromRgb(24, 52, 74)),
                Margin = new Thickness(0, 0, 0, 5)
            };
            root.Children.Add(heading);
            var note = new TextBlock
            {
                Text = model.Note,
                TextWrapping = TextWrapping.Wrap,
                Foreground = Brushes.DimGray,
                Margin = new Thickness(0, 0, 0, 14)
            };
            Grid.SetRow(note, 1);
            root.Children.Add(note);

            var groups = new StackPanel();
            foreach (IGrouping<string, ProductionSettingsField> group in
                model.Fields.GroupBy(item => item.Group))
            {
                var panel = new StackPanel { Margin = new Thickness(10) };
                foreach (ProductionSettingsField field in group)
                    panel.Children.Add(BuildFieldRow(field));
                groups.Children.Add(new Expander
                {
                    Header = group.Key,
                    IsExpanded = true,
                    Margin = new Thickness(0, 0, 0, 10),
                    Padding = new Thickness(4),
                    Content = panel,
                    FontWeight = FontWeights.SemiBold
                });
            }
            var scroll = new ScrollViewer
            {
                Content = groups,
                VerticalScrollBarVisibility = ScrollBarVisibility.Auto
            };
            Grid.SetRow(scroll, 2);
            root.Children.Add(scroll);

            var buttons = new StackPanel
            {
                Orientation = Orientation.Horizontal,
                HorizontalAlignment = HorizontalAlignment.Right,
                Margin = new Thickness(0, 12, 0, 0)
            };
            var save = new Button
            {
                Content = "Save Settings",
                IsDefault = true,
                MinWidth = 120,
                Padding = new Thickness(14, 7, 14, 7),
                Margin = new Thickness(0, 0, 8, 0)
            };
            save.Click += OnSave;
            buttons.Children.Add(save);
            buttons.Children.Add(new Button
            {
                Content = "Cancel",
                IsCancel = true,
                MinWidth = 95,
                Padding = new Thickness(14, 7, 14, 7)
            });
            Grid.SetRow(buttons, 3);
            root.Children.Add(buttons);
            Content = root;
        }

        public bool Accepted { get; private set; }

        private UIElement BuildFieldRow(ProductionSettingsField field)
        {
            var grid = new Grid { Margin = new Thickness(0, 0, 0, 10) };
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(250) });
            grid.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });
            var label = new StackPanel { Margin = new Thickness(0, 0, 12, 0) };
            label.Children.Add(new TextBlock
            {
                Text = field.Label,
                FontWeight = FontWeights.SemiBold
            });
            if (!string.IsNullOrWhiteSpace(field.Description))
            {
                string fieldDetails = field.Description;
                if (fieldDetails.Length > 100)
                {
                    label.Children.Add(new Expander
                    {
                        Header = fieldDetails.Length > 68
                            ? fieldDetails.Substring(0, 65) + "..."
                            : fieldDetails,
                        IsExpanded = false,
                        FontSize = 10,
                        FontWeight = FontWeights.Normal,
                        Foreground = Brushes.DimGray,
                        Content = new TextBlock
                        {
                            Text = fieldDetails,
                            TextWrapping = TextWrapping.Wrap,
                            FontSize = 10,
                            FontWeight = FontWeights.Normal,
                            Foreground = Brushes.DimGray,
                            Margin = new Thickness(0, 3, 0, 0)
                        }
                    });
                }
                else
                {
                    label.Children.Add(new TextBlock
                    {
                        Text = fieldDetails,
                        TextWrapping = TextWrapping.Wrap,
                        FontSize = 10,
                        FontWeight = FontWeights.Normal,
                        Foreground = Brushes.DimGray
                    });
                }
            }
            grid.Children.Add(label);

            Control control;
            if (field.Kind == ProductionSettingsFieldKind.PaperHeight ||
                field.Kind == ProductionSettingsFieldKind.Choice)
            {
                var combo = new ComboBox
                {
                    IsEditable = field.Kind == ProductionSettingsFieldKind.Choice,
                    Padding = new Thickness(7, 5, 7, 5),
                    FontWeight = FontWeights.Normal
                };
                List<string> choices = (field.Kind == ProductionSettingsFieldKind.PaperHeight
                    ? new[] { "1.8", "2.0", "2.5", "3.5", "5.0" }
                    : field.Choices).ToList();
                if (field.Kind == ProductionSettingsFieldKind.Choice)
                    combo.Items.Add(string.Empty);
                foreach (string choice in choices)
                    combo.Items.Add(choice);
                if (field.Kind == ProductionSettingsFieldKind.PaperHeight)
                {
                    string selected = choices.FirstOrDefault(choice =>
                        string.Equals(choice, field.Value, StringComparison.OrdinalIgnoreCase)) ??
                        "2.0";
                    combo.SelectedItem = selected;
                }
                else
                {
                    combo.Text = field.Value;
                }
                Func<string, IDictionary<string, string>> callback;
                if (_model.ChoiceChanges.TryGetValue(field.Key, out callback))
                    combo.SelectionChanged += (sender, args) => ApplyChoiceDependencies(callback,
                        combo.SelectedItem as string ?? combo.Text);
                control = combo;
            }
            else
            {
                control = new TextBox
                {
                    Text = field.Value,
                    Padding = new Thickness(7, 5, 7, 5),
                    FontWeight = FontWeights.Normal
                };
            }
            control.VerticalAlignment = VerticalAlignment.Top;
            Grid.SetColumn(control, 1);
            grid.Children.Add(control);
            _controls[field] = control;
            return grid;
        }

        private void ApplyChoiceDependencies(Func<string, IDictionary<string, string>> callback, string selected)
        {
            IDictionary<string, string> updates = callback(selected);
            if (updates == null) return;
            foreach (KeyValuePair<string, string> update in updates)
            {
                KeyValuePair<ProductionSettingsField, Control> target = _controls.FirstOrDefault(x =>
                    string.Equals(x.Key.Key, update.Key, StringComparison.OrdinalIgnoreCase));
                TextBox textbox = target.Value as TextBox;
                if (textbox != null) textbox.Text = update.Value;
            }
        }

        private void OnSave(object sender, RoutedEventArgs args)
        {
            foreach (KeyValuePair<ProductionSettingsField, Control> item in _controls)
            {
                ProductionSettingsField field = item.Key;
                var textBox = item.Value as TextBox;
                var combo = item.Value as ComboBox;
                string value = textBox != null
                    ? textBox.Text
                    : combo != null ? combo.Text : string.Empty;
                value = (value ?? string.Empty).Trim();
                if (field.Kind == ProductionSettingsFieldKind.PositiveInteger)
                {
                    int integer;
                    if (!int.TryParse(value, NumberStyles.Integer, CultureInfo.InvariantCulture, out integer) || integer <= 0)
                    {
                        ShowValidation(field.Label, "Enter a whole number greater than zero.");
                        return;
                    }
                }
                else if (field.Kind == ProductionSettingsFieldKind.PositiveDouble ||
                         field.Kind == ProductionSettingsFieldKind.PaperHeight)
                {
                    double number;
                    if (!ProductionSettingsDialogModel.TryDouble(value, out number) || number <= 0.0)
                    {
                        ShowValidation(field.Label, "Enter a number greater than zero.");
                        return;
                    }
                }
                field.Value = value;
            }

            if (!PopupLastUsedDefaults.Save(_rememberedDefaults))
            {
                Document document = AcApplication.DocumentManager.MdiActiveDocument;
                if (document != null) document.Editor.WriteMessage("\nCE Tools could not remember these popup defaults on this computer. The entered settings are still applied to this run.");
            }
            Accepted = true;
            DialogResult = true;
            Close();
        }

        private static void ShowValidation(string field, string message)
        {
            System.Windows.MessageBox.Show(
                field + ": " + message,
                "CE Tools Settings",
                MessageBoxButton.OK,
                MessageBoxImage.Warning);
        }
    }

    internal static class ProductionSettingsPersistenceStore
    {
        private const string RootName = "CE_TOOLS";
        private const string StoreName = "POPUP_SETTINGS";

        internal static void Load(Database database, ProductionSettingsDialogModel model)
        {
            if (database == null || model == null) return;
            try
            {
                using (Transaction transaction = database.TransactionManager.StartTransaction())
                {
                    DBDictionary named = transaction.GetObject(database.NamedObjectsDictionaryId, OpenMode.ForRead, false) as DBDictionary;
                    if (named == null || !named.Contains(RootName)) return;
                    DBDictionary root = transaction.GetObject(named.GetAt(RootName), OpenMode.ForRead, false) as DBDictionary;
                    if (root == null || !root.Contains(StoreName)) return;
                    DBDictionary store = transaction.GetObject(root.GetAt(StoreName), OpenMode.ForRead, false) as DBDictionary;
                    string key = Key(model.Title);
                    if (store == null || !store.Contains(key)) return;
                    Xrecord record = transaction.GetObject(store.GetAt(key), OpenMode.ForRead, false) as Xrecord;
                    if (record == null || record.Data == null) return;
                    var values = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
                    foreach (TypedValue item in record.Data)
                    {
                        if (item.TypeCode != (int)DxfCode.Text) continue;
                        string value = Convert.ToString(item.Value, CultureInfo.InvariantCulture) ?? string.Empty;
                        int split = value.IndexOf('\t');
                        if (split <= 0) continue;
                        values[value.Substring(0, split)] = value.Substring(split + 1);
                    }
                    foreach (ProductionSettingsField field in model.Fields)
                    {
                        string value;
                        if (values.TryGetValue(field.Key, out value)) field.Value = value;
                    }
                }
            }
            catch
            {
                // Settings persistence must never prevent a production command from opening.
            }
        }

        internal static void Save(Database database, ProductionSettingsDialogModel model)
        {
            if (database == null || model == null) return;
            try
            {
                using (Transaction transaction = database.TransactionManager.StartTransaction())
                {
                    DBDictionary named = transaction.GetObject(database.NamedObjectsDictionaryId, OpenMode.ForWrite, false) as DBDictionary;
                    if (named == null) return;
                    DBDictionary root;
                    if (named.Contains(RootName))
                        root = transaction.GetObject(named.GetAt(RootName), OpenMode.ForWrite, false) as DBDictionary;
                    else
                    {
                        root = new DBDictionary();
                        named.SetAt(RootName, root);
                        transaction.AddNewlyCreatedDBObject(root, true);
                    }
                    DBDictionary store;
                    if (root.Contains(StoreName))
                        store = transaction.GetObject(root.GetAt(StoreName), OpenMode.ForWrite, false) as DBDictionary;
                    else
                    {
                        store = new DBDictionary();
                        root.SetAt(StoreName, store);
                        transaction.AddNewlyCreatedDBObject(store, true);
                    }
                    string key = Key(model.Title);
                    Xrecord record;
                    if (store.Contains(key))
                        record = transaction.GetObject(store.GetAt(key), OpenMode.ForWrite, false) as Xrecord;
                    else
                    {
                        record = new Xrecord();
                        store.SetAt(key, record);
                        transaction.AddNewlyCreatedDBObject(record, true);
                    }
                    record.Data = new ResultBuffer(model.Fields
                        .Select(field => new TypedValue(
                            (int)DxfCode.Text,
                            field.Key + "\t" + (field.Value ?? string.Empty)))
                        .ToArray());
                    transaction.Commit();
                }
            }
            catch
            {
                // Commands remain usable even if a read-only drawing blocks persistence.
            }
        }

        private static string Key(string title)
        {
            unchecked
            {
                uint hash = 2166136261;
                foreach (char value in title ?? string.Empty)
                {
                    hash ^= char.ToUpperInvariant(value);
                    hash *= 16777619;
                }
                return "POPUP_" + hash.ToString("X8", CultureInfo.InvariantCulture);
            }
        }
    }

    internal static class ProductionStyleCatalog
    {
        public static IList<string> ReadNames(Database database, object styleCollection)
        {
            return ReadNames(database, styleCollection, string.Empty);
        }

        public static IList<string> ReadNames(
            Database database,
            object styleCollection,
            string category)
        {
            return CivilStyleDiscovery.ReadNames(database, styleCollection, category);
        }

        private static IEnumerable<object> Enumerate(object collection)
        {
            // CivilStyleDiscovery retains the "GetObjectIds" fallback, its
            // PropertyInfo countProperty lookup, and the
            // GetIndexParameters().Length == 1 integer-indexer fallback.
            return CivilStyleDiscovery.Enumerate(collection);
        }
    }
}
