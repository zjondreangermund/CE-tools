@echo off
setlocal
if "%~1"=="" (
 echo Usage: APPLY-CE-TOOLS-UPDATE.bat "C:\path\to\CE-tools-main"
 exit /b 2
)
where py >nul 2>nul
if %ERRORLEVEL% EQU 0 (
 py -3 "%~dp0APPLY-CE-TOOLS-UPDATE.py" "%~1"
) else (
 python "%~dp0APPLY-CE-TOOLS-UPDATE.py" "%~1"
)
endlocal
